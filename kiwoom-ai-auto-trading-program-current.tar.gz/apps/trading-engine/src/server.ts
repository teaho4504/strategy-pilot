import { createServer } from "node:http";
import { evaluatePairLagScalping, validateRiskBeforeOrder } from "@kiwoom/core";

const startedAt = new Date();
const port = Number(process.env.PORT ?? 8788);
const mode = process.env.APP_MODE ?? process.env.NEXT_PUBLIC_APP_MODE ?? "demo";
const allowedOrigin = process.env.ALLOWED_ORIGIN ?? "*";

const runtime = {
  hasKiwoomAppKey: Boolean(process.env.KIWOOM_APP_KEY),
  hasKiwoomAppSecret: Boolean(process.env.KIWOOM_APP_SECRET),
  hasKiwoomAccountNo: Boolean(process.env.KIWOOM_ACCOUNT_NO),
  hasDatabaseUrl: Boolean(process.env.DATABASE_URL),
  hasRedisUrl: Boolean(process.env.REDIS_URL),
  hasPythonWorkerUrl: Boolean(process.env.PYTHON_WORKER_URL),
  awsRegion: process.env.AWS_REGION ?? "ap-northeast-2",
};

const mockPair = {
  id: "pair-cloud-001",
  leaderSymbol: "000660",
  leaderName: "SK하이닉스",
  followerSymbol: "042700",
  followerName: "한미반도체",
  relationshipType: "sector" as const,
  description: "반도체 대장주와 후속주 반응 지연 감시",
  isActive: true,
  createdAt: startedAt.toISOString(),
  updatedAt: startedAt.toISOString(),
};

const mockStrategy = {
  id: "strategy-cloud-001",
  name: "눌림 후속주 스캘핑",
  description: "Cloud engine demo strategy",
  status: "실행 중" as const,
  strategyType: "pair_lag_scalping" as const,
  pairWatchlistId: mockPair.id,
  entryConditions: [
    { field: "leader_price_change_1m" as const, operator: ">=" as const, value: 2, score: 30 },
    { field: "follower_relative_lag" as const, operator: ">=" as const, value: 0.8, score: 25 },
    { field: "follower_turnover_ratio_5m" as const, operator: ">=" as const, value: 1.8, score: 20 },
    { field: "bid_ask_imbalance" as const, operator: ">=" as const, value: 1.3, score: 15 },
  ],
  risk: {
    dailyMaxLossKrw: 800000,
    dailyMaxLossPercent: 2,
    strategyMaxCapital: 5000000,
    symbolMaxWeightPercent: 25,
    maxOpenPositions: 5,
    maxOrderAmount: 1200000,
    stopLossPercent: 1.5,
    takeProfitPercent: 3,
    maxHoldingMinutes: 5,
    maxEntriesPerDay: 3,
  },
  dailyOrderLimit: 3,
  todayOrderCount: 0,
  todayPnlPercent: 0,
  lastSignalAt: new Date().toISOString(),
  createdAt: startedAt.toISOString(),
  updatedAt: startedAt.toISOString(),
};

function json(status: number, body: Record<string, unknown>) {
  return {
    status,
    headers: {
      "Access-Control-Allow-Origin": allowedOrigin,
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Content-Type": "application/json; charset=utf-8",
    },
    body: JSON.stringify(body, null, 2),
  };
}

function getEngineSnapshot() {
  const now = new Date();
  const swing = Math.sin(now.getSeconds() / 60);
  const ticks = {
    "000660": {
      symbol: "000660",
      name: "SK하이닉스",
      price: 198500 + Math.round(swing * 800),
      changePercent: 4.65 + swing * 0.25,
      turnoverRatio5m: 2.4,
      turnoverKrw: 158900000000,
      tradeStrength: 147,
      bidVolume: 126000,
      askVolume: 89000,
      programNetBuyScore: 8,
      foreignNetBuyScore: 7,
      institutionNetBuyScore: 6,
      updatedAt: now.toISOString(),
    },
    "042700": {
      symbol: "042700",
      name: "한미반도체",
      price: 71800 + Math.round(swing * 500),
      changePercent: 2.05 + swing * 0.18,
      turnoverRatio5m: 2.2,
      turnoverKrw: 49100000000,
      tradeStrength: 136,
      bidVolume: 76000,
      askVolume: 55000,
      programNetBuyScore: 8,
      foreignNetBuyScore: 5,
      institutionNetBuyScore: 6,
      updatedAt: now.toISOString(),
    },
  };

  const evaluation = evaluatePairLagScalping(mockPair, ticks, mockStrategy);
  const risk = validateRiskBeforeOrder({
    risk: mockStrategy.risk,
    dailyLossKrw: 0,
    dailyLossPercent: 0,
    openPositions: 1,
    orderAmount: 861600,
    entriesToday: 0,
    apiConnected: runtime.hasKiwoomAppKey && runtime.hasKiwoomAppSecret,
    killSwitchActive: false,
  });

  return {
    service: "kiwoom-trading-engine",
    mode,
    architecture: "node-engine-python-analysis-worker",
    orderExecution: mode === "live" ? "server-only" : "demo-disabled",
    pair: mockPair,
    strategy: mockStrategy.name,
    signal: evaluation,
    risk,
    updatedAt: now.toISOString(),
  };
}

async function getHybridAnalysisSnapshot() {
  const workerUrl = process.env.PYTHON_WORKER_URL;

  if (!workerUrl) {
    return {
      service: "kiwoom-trading-engine",
      mode,
      pythonWorker: {
        configured: false,
        role: "analysis-only",
        orderExecution: "disabled",
      },
      engine: getEngineSnapshot(),
      note: "Set PYTHON_WORKER_URL to attach the Python analysis worker.",
    };
  }

  try {
    const response = await fetch(`${workerUrl.replace(/\/$/, "")}/analysis/candidates`, {
      headers: { Accept: "application/json" },
    });

    if (!response.ok) {
      throw new Error(`Python worker responded ${response.status}`);
    }

    const analysis = (await response.json()) as Record<string, unknown>;

    return {
      service: "kiwoom-trading-engine",
      mode,
      pythonWorker: {
        configured: true,
        reachable: true,
        role: "analysis-only",
        orderExecution: "disabled",
      },
      engine: getEngineSnapshot(),
      analysis,
      finalOrderGate: "node-trading-engine",
    };
  } catch (error) {
    return {
      service: "kiwoom-trading-engine",
      mode,
      pythonWorker: {
        configured: true,
        reachable: false,
        role: "analysis-only",
        orderExecution: "disabled",
        error: error instanceof Error ? error.message : "Unknown worker error",
      },
      engine: getEngineSnapshot(),
      finalOrderGate: "node-trading-engine",
    };
  }
}

const server = createServer(async (req, res) => {
  if (req.method === "OPTIONS") {
    const response = json(204, {});
    res.writeHead(response.status, response.headers);
    res.end();
    return;
  }

  const url = new URL(req.url ?? "/", `http://${req.headers.host ?? "localhost"}`);
  const routes: Record<string, () => ReturnType<typeof json> | Promise<ReturnType<typeof json>>> = {
    "/health": () =>
      json(200, {
        ok: true,
        service: "kiwoom-trading-engine",
        mode,
        startedAt: startedAt.toISOString(),
        uptimeSeconds: Math.round(process.uptime()),
      }),
    "/runtime": () =>
      json(200, {
        service: "kiwoom-trading-engine",
        mode,
        runtime,
        note: "Secret values are intentionally not returned.",
      }),
    "/market/snapshot": () => json(200, getEngineSnapshot()),
    "/analysis/snapshot": async () => json(200, await getHybridAnalysisSnapshot()),
  };

  const response = (await routes[url.pathname]?.()) ?? json(404, { ok: false, error: "Not found" });
  res.writeHead(response.status, response.headers);
  res.end(response.body);
});

server.listen(port, () => {
  console.log(`Trading engine server listening on http://127.0.0.1:${port}`);
});
