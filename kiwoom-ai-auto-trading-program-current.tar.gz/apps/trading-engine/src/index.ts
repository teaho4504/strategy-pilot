import { buildOrderIntentKey, evaluatePairLagScalping, validateRiskBeforeOrder } from "@kiwoom/core";

const pair = {
  id: "pair-001",
  leaderSymbol: "005930",
  leaderName: "삼성전자",
  followerSymbol: "000660",
  followerName: "SK하이닉스",
  relationshipType: "sector" as const,
  description: "반도체 대장주 급등 후 후속주 반응 지연 추적",
  isActive: true,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};

const strategy = {
  id: "strategy-pair-lag-001",
  name: "대장주 후속주 반응 지연 스캘핑",
  description: "Mock engine strategy",
  status: "실행 중" as const,
  strategyType: "pair_lag_scalping" as const,
  pairWatchlistId: pair.id,
  entryConditions: [
    { field: "leader_price_change_1m" as const, operator: ">=" as const, value: 2, score: 30 },
    { field: "follower_relative_lag" as const, operator: ">=" as const, value: 0.8, score: 25 },
    { field: "follower_turnover_ratio_5m" as const, operator: ">=" as const, value: 1.8, score: 20 },
    { field: "bid_ask_imbalance" as const, operator: ">=" as const, value: 1.3, score: 15 },
    { field: "program_net_buy_score" as const, operator: ">=" as const, value: 5, score: 10 },
  ],
  risk: {
    dailyMaxLossKrw: 300000,
    dailyMaxLossPercent: 1.5,
    strategyMaxCapital: 5000000,
    symbolMaxWeightPercent: 20,
    maxOpenPositions: 3,
    maxOrderAmount: 1000000,
    stopLossPercent: 1.5,
    takeProfitPercent: 3,
    maxHoldingMinutes: 5,
    maxEntriesPerDay: 1,
  },
  dailyOrderLimit: 3,
  todayOrderCount: 0,
  todayPnlPercent: 0,
  lastSignalAt: "-",
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};

const ticks = {
  "005930": {
    symbol: "005930",
    name: "삼성전자",
    price: 80600,
    changePercent: 2.82,
    turnoverRatio5m: 2.4,
    turnoverKrw: 128400000000,
    tradeStrength: 148,
    bidVolume: 93400,
    askVolume: 70200,
    programNetBuyScore: 8,
    foreignNetBuyScore: 7,
    institutionNetBuyScore: 5,
    updatedAt: new Date().toISOString(),
  },
  "000660": {
    symbol: "000660",
    name: "SK하이닉스",
    price: 236500,
    changePercent: 1.62,
    turnoverRatio5m: 2.1,
    turnoverKrw: 92200000000,
    tradeStrength: 136,
    bidVolume: 82400,
    askVolume: 58000,
    programNetBuyScore: 9,
    foreignNetBuyScore: 6,
    institutionNetBuyScore: 4,
    updatedAt: new Date().toISOString(),
  },
};

const evaluation = evaluatePairLagScalping(pair, ticks, strategy);
const risk = validateRiskBeforeOrder({
  risk: strategy.risk,
  dailyLossKrw: 0,
  dailyLossPercent: 0,
  openPositions: 1,
  orderAmount: 946000,
  entriesToday: 0,
  apiConnected: true,
  killSwitchActive: false,
});

const intentKey = buildOrderIntentKey({
  strategyId: strategy.id,
  signalId: "signal-mock-001",
  symbol: pair.followerSymbol,
  side: "매수",
  tradingDate: "2026-06-25",
});

console.log(
  JSON.stringify(
    {
      mode: "mock",
      strategy: strategy.name,
      evaluation,
      risk,
      orderIntentCreated: evaluation.passed && risk.passed,
      duplicateKey: intentKey,
    },
    null,
    2,
  ),
);
