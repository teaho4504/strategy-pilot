import { KiwoomRealtimeClient, KiwoomRestClient } from "@kiwoom/kiwoom-client";

const symbol = process.env.KIWOOM_TEST_SYMBOL ?? "039490";
const realtimeTypes = (process.env.KIWOOM_REALTIME_TYPES ?? "0B")
  .split(",")
  .map((item) => item.trim())
  .filter(Boolean) as Array<"00" | "04" | "0B" | "0C" | "0D" | "0H">;
const timeoutMs = Number(process.env.KIWOOM_SMOKE_TIMEOUT_MS ?? 15000);

async function main() {
  assertRequiredEnv(["KIWOOM_APP_KEY", "KIWOOM_APP_SECRET"]);

  console.log(
    JSON.stringify(
      {
        step: "start",
        symbol,
        realtimeTypes,
        apiBaseUrl: process.env.KIWOOM_API_BASE_URL ?? "https://api.kiwoom.com",
        websocketUrl: process.env.KIWOOM_WEBSOCKET_URL ?? "wss://api.kiwoom.com:10000/api/dostk/websocket",
        appKey: mask(process.env.KIWOOM_APP_KEY),
        timeoutMs,
      },
      null,
      2,
    ),
  );

  const rest = new KiwoomRestClient({
    appKey: process.env.KIWOOM_APP_KEY ?? "",
    secretKey: process.env.KIWOOM_APP_SECRET ?? "",
    baseUrl: process.env.KIWOOM_API_BASE_URL,
  });

  const token = await rest.issueToken();
  console.log(JSON.stringify({ step: "token-issued", token: mask(token.token), expiresAt: token.expires_dt }, null, 2));

  const client = new KiwoomRealtimeClient({
    appKey: process.env.KIWOOM_APP_KEY ?? "",
    secretKey: process.env.KIWOOM_APP_SECRET ?? "",
    websocketUrl: process.env.KIWOOM_WEBSOCKET_URL,
  });

  let received = 0;
  let done = false;

  const finish = (code: number) => {
    if (done) return;
    done = true;
    client.close();
    console.log(JSON.stringify({ step: "finish", received }, null, 2));
    process.exit(code);
  };

  client.connect(
    token.token,
    (tick) => {
      received += 1;
      console.log(JSON.stringify({ step: "tick", received, tick }, null, 2));
      if (received >= Number(process.env.KIWOOM_SMOKE_MIN_TICKS ?? 1)) finish(0);
    },
    (status) => {
      console.log(JSON.stringify({ step: "status", status }, null, 2));
      if (status === "login") {
        client.subscribe({
          groupNo: "1",
          items: [symbol],
          types: realtimeTypes,
        });
        console.log(JSON.stringify({ step: "registered", symbol, realtimeTypes }, null, 2));
      }
      if (status.startsWith("login_failed")) finish(1);
    },
  );

  setTimeout(() => {
    console.log(JSON.stringify({ step: "timeout", message: "No realtime tick received before timeout." }, null, 2));
    finish(received > 0 ? 0 : 1);
  }, timeoutMs);
}

function assertRequiredEnv(keys: string[]) {
  const missing = keys.filter((key) => !process.env[key]);
  if (missing.length) {
    throw new Error(`Missing required env: ${missing.join(", ")}`);
  }
}

function mask(value?: string) {
  if (!value) return "";
  if (value.length <= 8) return "****";
  return `${value.slice(0, 4)}...${value.slice(-4)}`;
}

main().catch((error) => {
  console.error(JSON.stringify({ step: "error", message: error instanceof Error ? error.message : String(error) }, null, 2));
  process.exit(1);
});
