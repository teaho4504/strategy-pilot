export type TradingStatus = "실행 중" | "일시정지" | "오류" | "연결 끊김";
export type StrategyStatus = "실행 중" | "대기" | "일시정지" | "오류";
export type CandidateStatus = "감시" | "진입 대기" | "진입 후보" | "보유 중" | "제외";
export type OrderSide = "매수" | "매도";
export type OrderStatus = "대기" | "부분체결" | "체결" | "취소" | "실패";

export interface AccountSnapshot {
  mode: "demo" | "mock";
  brokerLabel: string;
  totalAsset: number;
  cash: number;
  cashRatio: number;
  cumulativePnl: number;
  dailyPnl: number;
  dailyPnlPercent: number;
  lastDataAgo: string;
}

export interface PairWatchlist {
  id: string;
  group: string;
  leaderSymbol: string;
  leaderName: string;
  leaderChangePercent: number;
  followerSymbol: string;
  followerName: string;
  followerChangePercent: number;
  lagPercent: number;
  turnoverRatio5m: number;
  bidAskImbalance: number;
  programSignal: string;
  institutionSignal: string;
  foreignSignal: string;
  score: number;
  status: CandidateStatus;
  linkedStrategyId: string;
}

export interface StrategyDailyPnl {
  date: string;
  pullback: number;
  momentum: number;
  scalping: number;
  total: number;
}

export interface AiWatchCandidate {
  id: string;
  strategyId: string;
  strategyName: string;
  symbol: string;
  symbolName: string;
  changePercent: number;
  status: "감시" | "진입 후보";
  reason: string;
  pairId: string;
}

export interface MarketSignal {
  symbol: string;
  price: number;
  changePercent: number;
  turnoverKrw: number;
  tradeStrength: number;
  candles: Array<{ time: string; one: number; three: number; five: number }>;
  orderBook: Array<{ side: "ask" | "bid"; price: number; volume: number }>;
  executions: Array<{ time: string; price: number; quantity: number; side: OrderSide }>;
  supply: Array<{ label: string; value: string; tone: "gain" | "loss" | "safe" }>;
  sixMonthTimeline: TradeTimeline[];
}

export interface TradeTimeline {
  id: string;
  symbol: string;
  symbolName: string;
  date: string;
  steps: Array<{ label: "신호" | "주문" | "체결" | "손익"; value: string; tone?: "gain" | "loss" | "safe" | "caution" }>;
}

export interface ThemeCategory {
  id: string;
  label: string;
  description: string;
  source: "mock" | "kiwoom" | "web";
  symbols: string[];
}

export interface MarketIndexQuote {
  id: string;
  label: string;
  value: number;
  changePercent: number;
  market: "KR" | "US" | "FX" | "FUTURES";
  session: "정규장" | "프리마켓" | "야간" | "24H" | "지연";
  source: "kiwoom" | "external" | "mock";
}

export interface MarketInsight {
  id: string;
  title: string;
  summary: string;
  tone: "gain" | "loss" | "safe" | "caution";
  source: "kiwoom" | "news" | "investing" | "youtube" | "flow" | "mock";
  updatedAt: string;
}

export interface MarketSummarySnapshot {
  updatedAt: string;
  indexes: MarketIndexQuote[];
  futures: MarketIndexQuote[];
  kospiNewsInsight: MarketInsight;
  kosdaqNewsInsight: MarketInsight;
  kospiFlowInsight: MarketInsight;
  kosdaqFlowInsight: MarketInsight;
  usLiveInsight: MarketInsight;
  strategyBase: string[];
  providerNotes: string[];
}

export interface KiwoomConnectionStatus {
  configured: boolean;
  connected: boolean;
  mode: "mock" | "paper" | "live";
  message: string;
  availableScopes: string[];
  missingEnv: string[];
}

export interface Signal {
  id: string;
  pairId: string;
  score: number;
  createdAt: string;
  reason: string;
}

export interface Strategy {
  id: string;
  name: string;
  market: string;
  pairId: string;
  status: StrategyStatus;
  pnlPercent: number;
  todaySignals: number;
  todayFills: number;
  lastSignalAgo: string;
  dailyLossLimit: number;
  capitalUsed: number;
  capitalLimit: number;
  currentHolding: string | null;
  errorReason?: string;
}

export interface OrderIntent {
  id: string;
  strategyId: string;
  signalId: string;
  symbol: string;
  side: OrderSide;
  quantity: number;
  limitPrice: number;
  reason: {
    strategyName: string;
    signalScore: number;
    leaderChangePercent: number;
    lagPercent: number;
    turnoverRatio: number;
    bidAskImbalance: number;
  };
}

export interface Order {
  id: string;
  intentId: string;
  symbol: string;
  symbolName: string;
  side: OrderSide;
  strategyName: string;
  quantity: number;
  price: number;
  filledQuantity: number;
  remainingQuantity: number;
  submittedAt: string;
  elapsed: string;
  status: OrderStatus;
  cancelable: boolean;
}

export interface Fill {
  id: string;
  orderId: string;
  symbol: string;
  quantity: number;
  price: number;
  filledAt: string;
}

export interface Position {
  symbol: string;
  symbolName: string;
  quantity: number;
  avgPrice: number;
  pnlPercent: number;
}

export interface RiskSettings {
  dailyLossLimit: number;
  strategyCapitalLimit: number;
  symbolMaxWeightPercent: number;
  maxOpenPositions: number;
  dailyOrderLimit: number;
  alerts: {
    strategyError: boolean;
    orderFailure: boolean;
    dailyLossLimit: boolean;
    largePnl: boolean;
  };
}

export interface AnalyticsSnapshot {
  realizedPnl: number;
  winRate: number;
  averageProfit: number;
  averageLoss: number;
  mdd: number;
  averageHoldingMinutes: number;
  fillCount: number;
  strategyContribution: Array<{ label: string; value: number }>;
  pairPerformance: Array<{ label: string; pnl: number; winRate: number }>;
  scoreBuckets: Array<{ label: string; winRate: number }>;
  hourlyPerformance: Array<{ hour: string; fills: number }>;
  lossTags: Array<{ label: string; count: number }>;
}

export interface MarketDataAdapter {
  getWatchPairs(): Promise<PairWatchlist[]>;
  getMarketSignal(symbol: string): Promise<MarketSignal | undefined>;
  searchSymbols(keyword: string): Promise<Array<{ symbol: string; name: string; market: "KOSPI" | "KOSDAQ" }>>;
}

export interface BrokerAdapter {
  getAccountSnapshot(): Promise<AccountSnapshot>;
}

export interface OrderExecutionAdapter {
  getOrders(): Promise<Order[]>;
  createOrderIntent(intent: OrderIntent): Promise<OrderIntent>;
}

export interface AccountAdapter {
  getPositions(): Promise<Position[]>;
}
