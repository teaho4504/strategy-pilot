import { accountSnapshot } from "../mocks/trading";
import type { AccountSnapshot, BrokerAdapter } from "../types/trading";

export const portfolioService: BrokerAdapter = {
  async getAccountSnapshot(): Promise<AccountSnapshot> {
    return accountSnapshot;
  },
};
