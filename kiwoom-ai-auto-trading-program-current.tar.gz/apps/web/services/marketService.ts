import { marketSummarySnapshot } from "../mocks/trading";
import type { MarketSummarySnapshot } from "../types/trading";
import { getKiwoomConnectionStatus } from "./kiwoomService";

export async function getMarketSummary(): Promise<MarketSummarySnapshot> {
  const kiwoom = getKiwoomConnectionStatus();

  return {
    ...marketSummarySnapshot,
    providerNotes: [
      ...marketSummarySnapshot.providerNotes,
      kiwoom.configured
        ? "키움 서버 키 설정 확인됨 · 토큰 발급/시세 호출은 trading-engine에서 처리 예정"
        : `키움 서버 키 미설정 · 누락: ${kiwoom.missingEnv.join(", ")}`,
    ],
  };
}
