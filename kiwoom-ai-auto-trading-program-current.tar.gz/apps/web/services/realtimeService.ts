import { marketSignals } from "../mocks/trading";
import type { MarketSignal, OrderSide } from "../types/trading";

export interface RealtimeSnapshot {
  mode: "mock-stream" | "kiwoom-websocket";
  provider: "mock" | "kiwoom";
  connected: boolean;
  latencyMs: number;
  updatedAt: string;
  statusMessage: string;
  signal: MarketSignal;
}

export function createMockRealtimeSnapshot(symbol = "042700", now = new Date()): RealtimeSnapshot {
  const base = marketSignals[symbol] ?? marketSignals["042700"];
  const tick = Math.floor(now.getTime() / 1000);
  const wave = Math.sin(tick / 4);
  const micro = Math.cos(tick / 7);
  const priceDelta = Math.round(wave * 380 + micro * 120);
  const price = Math.max(1, base.price + priceDelta);
  const side: OrderSide = tick % 3 === 0 ? "매도" : "매수";
  const timeLabel = now.toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit", hour12: false });

  return {
    mode: "mock-stream",
    provider: "mock",
    connected: true,
    latencyMs: 260 + Math.round(Math.abs(wave) * 80),
    updatedAt: now.toISOString(),
    statusMessage: "Mock realtime stream. Set REALTIME_PROVIDER=kiwoom on the server to use Kiwoom WebSocket.",
    signal: {
      ...base,
      price,
      changePercent: Number((base.changePercent + wave * 0.18).toFixed(2)),
      turnoverKrw: Math.round(base.turnoverKrw * (1 + wave * 0.015)),
      tradeStrength: Math.max(80, Math.round(base.tradeStrength + wave * 8)),
      candles: [
        ...base.candles.slice(1),
        {
          time: timeLabel,
          one: price,
          three: price - Math.round(wave * 220),
          five: price - Math.round(micro * 180),
        },
      ],
      orderBook: base.orderBook.map((row, index) => ({
        ...row,
        price: row.price + priceDelta,
        volume: Math.max(100, Math.round(row.volume * (1 + Math.sin(tick / (index + 3)) * 0.12))),
      })),
      executions: [
        {
          time: now.toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }),
          price,
          quantity: 1 + (tick % 9),
          side,
        },
        ...base.executions,
      ].slice(0, 8),
    },
  };
}

export function mergeRealtimeTick(base: MarketSignal, tick: { price?: number; changePercent?: number; updatedAt?: string }): MarketSignal {
  const price = tick.price && tick.price > 0 ? tick.price : base.price;
  const changePercent = Number((tick.changePercent ?? base.changePercent).toFixed(2));
  const now = tick.updatedAt ? new Date(tick.updatedAt) : new Date();
  const timeLabel = now.toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit", hour12: false });
  const side: OrderSide = changePercent >= base.changePercent ? "매수" : "매도";

  return {
    ...base,
    price,
    changePercent,
    candles: [
      ...base.candles.slice(1),
      {
        time: timeLabel,
        one: price,
        three: Math.round((price + base.price) / 2),
        five: base.candles.at(-1)?.five ?? price,
      },
    ],
    executions: [
      {
        time: now.toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }),
        price,
        quantity: 1,
        side,
      },
      ...base.executions,
    ].slice(0, 8),
  };
}
