import { analytics, strategies } from "../mocks/trading";
import type { AnalyticsSnapshot, Strategy } from "../types/trading";

export const strategyService = {
  async getStrategies(): Promise<Strategy[]> {
    return strategies;
  },
  async getAnalytics(): Promise<AnalyticsSnapshot> {
    return analytics;
  },
};
