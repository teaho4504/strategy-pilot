export interface BrokerCredentialInput {
  appKey?: string;
  secretKey?: string;
  accountNo?: string;
  fixedIp?: string;
  sampleReceived?: boolean;
}

export interface BrokerSetupResult {
  ok: boolean;
  mode: "demo-validation" | "server-secret-plan";
  stored: boolean;
  storageProvider: "dry-run" | "env" | "aws-secrets-manager";
  missing: string[];
  appKeyLast4: string;
  accountNoMasked: string;
  message: string;
  nextSteps: string[];
  sampleStatus: string;
}

export async function prepareBrokerCredentialSetup(input: BrokerCredentialInput): Promise<BrokerSetupResult> {
  const missing = [
    !input.appKey?.trim() ? "KIWOOM_APP_KEY" : null,
    !input.secretKey?.trim() ? "KIWOOM_APP_SECRET" : null,
    !input.accountNo?.trim() ? "KIWOOM_ACCOUNT_NO" : null,
    !input.fixedIp?.trim() ? "AWS_FIXED_IP" : null,
  ].filter((item): item is string => Boolean(item));

  const storageProvider = resolveStorageProvider();
  const canPersist = storageProvider === "aws-secrets-manager" && Boolean(process.env.AWS_REGION && process.env.KIWOOM_SECRET_ID);

  return {
    ok: missing.length === 0,
    mode: canPersist ? "server-secret-plan" : "demo-validation",
    stored: false,
    storageProvider,
    missing,
    appKeyLast4: input.appKey ? input.appKey.slice(-4) : "",
    accountNoMasked: input.accountNo ? maskAccount(input.accountNo) : "",
    message: buildMessage({ missing, storageProvider, canPersist }),
    nextSteps: buildNextSteps({ storageProvider, canPersist }),
    sampleStatus: input.sampleReceived ? "실시간 응답 샘플 확보됨" : "실시간 응답 샘플 필요",
  };
}

function resolveStorageProvider(): BrokerSetupResult["storageProvider"] {
  const provider = process.env.SECRET_STORE_PROVIDER;
  if (provider === "aws-secrets-manager") return "aws-secrets-manager";
  if (provider === "env") return "env";
  return "dry-run";
}

function buildMessage({
  missing,
  storageProvider,
  canPersist,
}: {
  missing: string[];
  storageProvider: BrokerSetupResult["storageProvider"];
  canPersist: boolean;
}) {
  if (missing.length > 0) return "실제 연결 전 필수 항목이 남아 있습니다.";
  if (canPersist) return "서버 보안 저장 어댑터 준비 완료. 운영 배포에서는 AWS Secrets Manager 저장 액션으로 연결합니다.";
  if (storageProvider === "env") return "입력 형식 확인 완료. 현재 런타임 환경변수는 실행 중 변경할 수 없으므로 서버 배포 환경에 등록해야 합니다.";
  if (storageProvider === "aws-secrets-manager") return "AWS Secrets Manager 모드가 선택됐지만 AWS_REGION 또는 KIWOOM_SECRET_ID가 필요합니다.";
  return "입력 형식 확인 완료. 현재는 데모 검증 모드이며 값은 저장되지 않습니다.";
}

function buildNextSteps({
  storageProvider,
  canPersist,
}: {
  storageProvider: BrokerSetupResult["storageProvider"];
  canPersist: boolean;
}) {
  return [
    "AWS EC2/Lightsail 고정 IP를 키움 허용 IP로 등록",
    storageProvider === "aws-secrets-manager"
      ? "AWS Secrets Manager에 KIWOOM_APP_KEY, KIWOOM_APP_SECRET, KIWOOM_ACCOUNT_NO 저장"
      : "KIWOOM_APP_KEY, KIWOOM_APP_SECRET, KIWOOM_ACCOUNT_NO를 서버 환경변수에만 저장",
    "REALTIME_PROVIDER=kiwoom 설정 후 WebSocket 수신 샘플 확인",
    canPersist ? "Secrets 저장 후 엔진 재시작 없이 상태 재확인" : "배포 환경변수 또는 Secrets Manager 설정 후 엔진 재배포",
    "모의투자에서 주문/체결/리스크 로그 검증 후 live 전환",
  ];
}

function maskAccount(value: string) {
  const compact = value.replace(/[^\d]/g, "");
  if (compact.length <= 4) return "****";
  return `${compact.slice(0, 2)}****${compact.slice(-2)}`;
}
