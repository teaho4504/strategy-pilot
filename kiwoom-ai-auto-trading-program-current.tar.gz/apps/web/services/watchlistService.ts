import { marketSignals, watchPairs } from "../mocks/trading";
import type { MarketDataAdapter, MarketSignal, PairWatchlist } from "../types/trading";

export const watchlistService: MarketDataAdapter = {
  async getWatchPairs(): Promise<PairWatchlist[]> {
    return watchPairs;
  },
  async getMarketSignal(symbol: string): Promise<MarketSignal | undefined> {
    return marketSignals[symbol] ?? marketSignals["042700"];
  },
  async searchSymbols(keyword: string): Promise<Array<{ symbol: string; name: string; market: "KOSPI" | "KOSDAQ" }>> {
    const symbols = [
      { symbol: "000660", name: "SK하이닉스", market: "KOSPI" as const },
      { symbol: "042700", name: "한미반도체", market: "KOSPI" as const },
      { symbol: "034020", name: "두산에너빌리티", market: "KOSPI" as const },
      { symbol: "247540", name: "에코프로비엠", market: "KOSDAQ" as const },
    ];

    return symbols.filter((item) => item.name.includes(keyword) || item.symbol.includes(keyword));
  },
};
