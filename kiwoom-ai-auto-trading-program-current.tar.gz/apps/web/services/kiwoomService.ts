import type { KiwoomConnectionStatus } from "../types/trading";

export function getKiwoomConnectionStatus(): KiwoomConnectionStatus {
  const required = ["KIWOOM_APP_KEY", "KIWOOM_APP_SECRET", "KIWOOM_ACCOUNT_NO"];
  const missingEnv = required.filter((key) => !process.env[key]);

  return {
    configured: missingEnv.length === 0,
    connected: false,
    mode: "mock",
    message:
      missingEnv.length === 0
        ? "서버 환경변수 확인 완료 · 로그인 토큰 발급 대기"
        : "키움 API 키/시크릿/계좌번호는 서버 환경변수에만 설정해야 합니다.",
    availableScopes: ["국내주식 시세", "차트", "조건검색", "계좌", "주문 준비"],
    missingEnv,
  };
}
