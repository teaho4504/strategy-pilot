import { riskSettings } from "../mocks/trading";
import type { RiskSettings } from "../types/trading";

export const riskService = {
  async getRiskSettings(): Promise<RiskSettings> {
    return riskSettings;
  },
};
