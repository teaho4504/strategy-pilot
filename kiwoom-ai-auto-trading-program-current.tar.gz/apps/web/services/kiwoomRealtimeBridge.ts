import { KiwoomRealtimeClient, KiwoomRestClient } from "../../../packages/kiwoom-client/src/index";
import { marketSignals } from "../mocks/trading";
import type { MarketSignal } from "../types/trading";
import { createMockRealtimeSnapshot, mergeRealtimeTick, type RealtimeSnapshot } from "./realtimeService";

type BridgeStatus = "idle" | "connecting" | "connected" | "error" | "disabled";

interface TickCache {
  price?: number;
  changePercent?: number;
  updatedAt?: string;
}

class KiwoomRealtimeBridge {
  private status: BridgeStatus = "idle";
  private lastError: string | null = null;
  private client: KiwoomRealtimeClient | null = null;
  private tokenIssuedAt = 0;
  private ticks = new Map<string, TickCache>();
  private subscribedSymbols = new Set<string>();

  async snapshot(symbol: string): Promise<RealtimeSnapshot> {
    if (process.env.REALTIME_PROVIDER !== "kiwoom") {
      return createMockRealtimeSnapshot(symbol);
    }

    const missing = requiredEnv().filter((key) => !process.env[key]);
    if (missing.length) {
      const fallback = createMockRealtimeSnapshot(symbol);
      return {
        ...fallback,
        provider: "kiwoom",
        connected: false,
        statusMessage: `Kiwoom WebSocket disabled. Missing server env: ${missing.join(", ")}`,
      };
    }

    await this.ensureStarted(symbol);
    const base = marketSignals[symbol] ?? marketSignals["042700"];
    const tick = this.ticks.get(symbol);
    const signal: MarketSignal = tick ? mergeRealtimeTick(base, tick) : base;

    return {
      mode: "kiwoom-websocket",
      provider: "kiwoom",
      connected: this.status === "connected",
      latencyMs: tick?.updatedAt ? Math.max(0, Date.now() - new Date(tick.updatedAt).getTime()) : 0,
      updatedAt: tick?.updatedAt ?? new Date().toISOString(),
      statusMessage: this.statusMessage(),
      signal,
    };
  }

  private async ensureStarted(symbol: string) {
    if (this.status === "connecting" || this.status === "connected") {
      this.subscribe(symbol);
      return;
    }

    this.status = "connecting";
    this.lastError = null;

    try {
      const rest = new KiwoomRestClient({
        appKey: process.env.KIWOOM_APP_KEY ?? "",
        secretKey: process.env.KIWOOM_APP_SECRET ?? "",
        baseUrl: process.env.KIWOOM_API_BASE_URL,
      });
      const token = await rest.issueToken();
      this.tokenIssuedAt = Date.now();

      this.client = new KiwoomRealtimeClient({
        appKey: process.env.KIWOOM_APP_KEY ?? "",
        secretKey: process.env.KIWOOM_APP_SECRET ?? "",
        websocketUrl: process.env.KIWOOM_WEBSOCKET_URL,
      });

      this.client.connect(
        token.token,
        (tick) => {
          if (!tick.symbol) return;
          this.ticks.set(tick.symbol, {
            price: tick.price,
            changePercent: tick.changePercent,
            updatedAt: tick.updatedAt,
          });
        },
        (status) => {
          this.status = status === "connected" ? "connected" : status === "closed" ? "idle" : "error";
          if (status === "error") this.lastError = "Kiwoom realtime socket error";
        },
      );
      this.subscribe(symbol);
    } catch (error) {
      this.status = "error";
      this.lastError = error instanceof Error ? error.message : "Unknown Kiwoom realtime error";
    }
  }

  private subscribe(symbol: string) {
    if (!this.client || this.subscribedSymbols.has(symbol)) return;
    this.subscribedSymbols.add(symbol);
    this.client.subscribe({
      groupNo: "AUTO_TRADING_MVP",
      items: [symbol],
      types: ["00", "04", "0B", "0C", "0D", "0H"],
    });
  }

  private statusMessage() {
    if (this.lastError) return this.lastError;
    if (this.status === "connected") return "Kiwoom WebSocket connected on server. Browser receives internal snapshot only.";
    if (this.status === "connecting") return "Kiwoom WebSocket connecting. Waiting for first realtime tick.";
    return `Kiwoom WebSocket status: ${this.status}.`;
  }
}

function requiredEnv() {
  return ["KIWOOM_APP_KEY", "KIWOOM_APP_SECRET"];
}

const globalForKiwoom = globalThis as typeof globalThis & {
  __kiwoomRealtimeBridge?: KiwoomRealtimeBridge;
};

export function getKiwoomRealtimeBridge() {
  globalForKiwoom.__kiwoomRealtimeBridge ??= new KiwoomRealtimeBridge();
  return globalForKiwoom.__kiwoomRealtimeBridge;
}
