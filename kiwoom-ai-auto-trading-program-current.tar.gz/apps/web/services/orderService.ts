import { orders } from "../mocks/trading";
import type { Order, OrderExecutionAdapter, OrderIntent } from "../types/trading";

export const orderService: OrderExecutionAdapter = {
  async getOrders(): Promise<Order[]> {
    return orders;
  },
  async createOrderIntent(intent: OrderIntent): Promise<OrderIntent> {
    return intent;
  },
};
