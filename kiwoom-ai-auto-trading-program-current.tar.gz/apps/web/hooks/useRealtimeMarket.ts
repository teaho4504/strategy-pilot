"use client";

import { useEffect, useState } from "react";
import { createMockRealtimeSnapshot, type RealtimeSnapshot } from "../services/realtimeService";

export function useRealtimeMarket(symbol: string, intervalMs = 1000) {
  const [snapshot, setSnapshot] = useState<RealtimeSnapshot>(() => createMockRealtimeSnapshot(symbol));

  useEffect(() => {
    setSnapshot(createMockRealtimeSnapshot(symbol));
    const timer = window.setInterval(() => {
      setSnapshot(createMockRealtimeSnapshot(symbol));
    }, intervalMs);

    return () => window.clearInterval(timer);
  }, [symbol, intervalMs]);

  return snapshot;
}
