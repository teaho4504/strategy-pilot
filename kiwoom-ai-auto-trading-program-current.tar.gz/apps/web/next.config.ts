import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  transpilePackages: ["@kiwoom/core"],
  allowedDevOrigins: ["http://127.0.0.1:3000", "http://localhost:3000"],
};

export default nextConfig;
