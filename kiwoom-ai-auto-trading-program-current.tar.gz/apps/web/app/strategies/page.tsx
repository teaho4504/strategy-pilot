import { DashboardApp } from "../page";

export default function StrategiesPage() {
  return <DashboardApp initialTab="strategies" />;
}
