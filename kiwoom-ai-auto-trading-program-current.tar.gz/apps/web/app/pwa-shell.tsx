"use client";

import { useEffect, useState } from "react";
import { CloudOff, RefreshCw, Smartphone } from "lucide-react";

export function PwaShell() {
  const [online, setOnline] = useState(true);
  const [standalone, setStandalone] = useState(false);

  useEffect(() => {
    setOnline(navigator.onLine);
    setStandalone(window.matchMedia("(display-mode: standalone)").matches || (navigator as Navigator & { standalone?: boolean }).standalone === true);

    const onOnline = () => setOnline(true);
    const onOffline = () => setOnline(false);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);

    if ("serviceWorker" in navigator && process.env.NODE_ENV === "production") {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }

    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, []);

  if (online && standalone) return null;

  return (
    <div className="pointer-events-none fixed left-1/2 top-2 z-50 w-[calc(100%-24px)] max-w-md -translate-x-1/2">
      {!online ? (
        <div className="flex items-center gap-2 rounded-xl border border-caution/40 bg-caution/15 px-3 py-2 text-xs text-caution shadow-glow backdrop-blur">
          <CloudOff size={14} />
          네트워크 연결 끊김 · 마지막 데이터로 표시 중
        </div>
      ) : !standalone ? (
        <div className="flex items-center gap-2 rounded-xl border border-line bg-panel/90 px-3 py-2 text-xs text-slate-400 shadow-glow backdrop-blur">
          <Smartphone size={14} />
          모바일 홈 화면에 추가하면 앱처럼 실행됩니다.
          <RefreshCw size={13} className="ml-auto text-safe" />
        </div>
      ) : null}
    </div>
  );
}
