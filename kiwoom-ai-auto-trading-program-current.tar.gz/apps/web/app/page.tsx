"use client";

import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  BarChart3,
  Bell,
  Bot,
  ChevronLeft,
  ChevronRight,
  Copy,
  Home,
  Layers,
  Link,
  ListChecks,
  Pause,
  Play,
  Plus,
  Power,
  RefreshCw,
  Search,
  Settings,
  Shield,
  Trash2,
  Wallet,
  X,
  Zap,
} from "lucide-react";
import { Area, AreaChart, Bar, BarChart, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import {
  accountSnapshot,
  aiWatchCandidates,
  analytics,
  marketSummarySnapshot,
  orders,
  riskSettings,
  strategies,
  strategyDailyPnl,
  themeCategories,
  tradeTimelines,
  watchPairs,
} from "../mocks/trading";
import { useRealtimeMarket } from "../hooks/useRealtimeMarket";
import { apiFetch, appModeLabel } from "../lib/api-client";
import type {
  CandidateStatus,
  KiwoomConnectionStatus,
  MarketIndexQuote,
  MarketInsight,
  MarketSignal,
  MarketSummarySnapshot,
  Order,
  PairWatchlist,
  RiskSettings,
  Strategy,
  StrategyStatus,
  TradeTimeline,
} from "../types/trading";
import { cx, signedPct } from "../lib/ui";

type Tab = "home" | "watch" | "strategies" | "orders" | "settings";
type Screen =
  | { name: "main" }
  | { name: "watchDetail"; pairId: string }
  | { name: "strategyDetail"; strategyId: string }
  | { name: "strategyBuilder" };

const navItems: Array<{ id: Tab; label: string; icon: React.ComponentType<{ size?: number }> }> = [
  { id: "home", label: "홈", icon: Home },
  { id: "watch", label: "감시", icon: Zap },
  { id: "strategies", label: "전략", icon: Layers },
  { id: "orders", label: "주문", icon: ListChecks },
  { id: "settings", label: "설정", icon: Settings },
];

const statusCopy: Record<StrategyStatus, string> = {
  "실행 중": "bg-safe/15 text-safe border-safe/35",
  대기: "bg-slate-500/15 text-slate-300 border-line",
  일시정지: "bg-caution/15 text-caution border-caution/35",
  오류: "bg-gain/15 text-gain border-gain/35",
};

export default function Page() {
  return <DashboardApp initialTab="home" />;
}

export function DashboardApp({ initialTab }: { initialTab: Tab }) {
  const [tab, setTab] = useState<Tab>(initialTab);
  const [screen, setScreen] = useState<Screen>({ name: "main" });
  const [tradingStatus, setTradingStatus] = useState<"일시정지" | "실행 중" | "중지됨">("일시정지");
  const [killOpen, setKillOpen] = useState(false);
  const [killConfirm, setKillConfirm] = useState(false);
  const [orderReason, setOrderReason] = useState<Order | null>(null);
  const [builderConverted, setBuilderConverted] = useState(false);
  const [settingsState, setSettingsState] = useState<RiskSettings>(riskSettings);

  const activePair = screen.name === "watchDetail" ? watchPairs.find((pair) => pair.id === screen.pairId) : undefined;
  const activeStrategy =
    screen.name === "strategyDetail" ? strategies.find((strategy) => strategy.id === screen.strategyId) : undefined;

  function goTab(next: Tab) {
    setTab(next);
    setScreen({ name: "main" });
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col bg-ink text-slate-50 shadow-glow">
      <AppHeader />
      <section className="flex-1 overflow-y-auto px-4 pb-28 pt-4">
        {screen.name === "watchDetail" && activePair ? (
          <WatchDetailScreen pair={activePair} onBack={() => setScreen({ name: "main" })} />
        ) : null}
        {screen.name === "strategyDetail" && activeStrategy ? (
          <StrategyDetailScreen strategy={activeStrategy} onBack={() => setScreen({ name: "main" })} />
        ) : null}
        {screen.name === "strategyBuilder" ? (
          <StrategyBuilderScreen
            converted={builderConverted}
            onConvert={() => setBuilderConverted(true)}
            onBack={() => setScreen({ name: "main" })}
          />
        ) : null}
        {screen.name === "main" && tab === "home" ? (
          <HomeScreen
            tradingStatus={tradingStatus}
            onStart={() => setTradingStatus("실행 중")}
            onPause={() => setTradingStatus("일시정지")}
            onKill={() => setKillOpen(true)}
            onWatchDetail={(pairId) => {
              setTab("watch");
              setScreen({ name: "watchDetail", pairId });
            }}
          />
        ) : null}
        {screen.name === "main" && tab === "watch" ? (
          <WatchScreen onSelectPair={(pairId) => setScreen({ name: "watchDetail", pairId })} />
        ) : null}
        {screen.name === "main" && tab === "strategies" ? (
          <StrategiesScreen
            onOpenBuilder={() => setScreen({ name: "strategyBuilder" })}
            onOpenDetail={(strategyId) => setScreen({ name: "strategyDetail", strategyId })}
          />
        ) : null}
        {screen.name === "main" && tab === "orders" ? <OrdersScreen onReason={setOrderReason} /> : null}
        {screen.name === "main" && tab === "settings" ? (
          <SettingsScreen settings={settingsState} onChange={setSettingsState} />
        ) : null}
      </section>
      <BottomNav active={tab} onSelect={goTab} />
      {killOpen ? (
        <KillSwitchModal
          confirmed={killConfirm}
          onClose={() => {
            setKillOpen(false);
            setKillConfirm(false);
          }}
          onPrimary={() => {
            if (!killConfirm) {
              setKillConfirm(true);
              return;
            }
            setTradingStatus("중지됨");
            setKillOpen(false);
            setKillConfirm(false);
          }}
        />
      ) : null}
      {orderReason ? <OrderReasonSheet order={orderReason} onClose={() => setOrderReason(null)} /> : null}
    </main>
  );
}

function AppHeader() {
  const modeLabel = appModeLabel();

  return (
    <header className="sticky top-0 z-20 border-b border-line bg-ink/95 px-5 py-4 backdrop-blur">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="rounded-full border border-caution/40 bg-caution/15 px-2.5 py-1 text-[11px] font-semibold text-caution">
            ● {modeLabel}
          </span>
          <span className="text-sm font-semibold text-slate-100">{accountSnapshot.brokerLabel}</span>
        </div>
        <div className="relative">
          <Bell size={18} className="text-slate-300" />
          <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-gain" />
        </div>
      </div>
    </header>
  );
}

function HomeScreen({
  tradingStatus,
  onStart,
  onPause,
  onKill,
  onWatchDetail,
}: {
  tradingStatus: string;
  onStart: () => void;
  onPause: () => void;
  onKill: () => void;
  onWatchDetail: (pairId: string) => void;
}) {
  return (
    <div className="space-y-4">
      <p className="text-xs text-slate-400">
        모의투자 · 엔진 연결됨 · 자동매매 {tradingStatus} · 마지막 데이터 수신 {accountSnapshot.lastDataAgo}
      </p>
      <AssetCard />
      <AutoTradingCard tradingStatus={tradingStatus} onStart={onStart} onPause={onPause} onKill={onKill} />
      <HomeActiveStrategies />
      <HomeWatchSummary onSelectPair={onWatchDetail} />
      <Panel title="오늘의 타임라인" subtitle="종목별 신호 → 주문 → 체결 → 손익">
        <Timeline onSelectPair={onWatchDetail} />
      </Panel>
      <MarketSummary />
    </div>
  );
}

function AutoTradingCard({
  tradingStatus,
  onStart,
  onPause,
  onKill,
}: {
  tradingStatus: string;
  onStart: () => void;
  onPause: () => void;
  onKill: () => void;
}) {
  return (
    <Panel title="전체 자동매매" action={tradingStatus}>
      <div className="mb-3 flex items-center justify-between rounded-xl border border-line bg-ink px-3 py-2">
        <div>
          <p className="flex items-center gap-2 text-sm font-semibold">
            <span className={cx("h-2.5 w-2.5 rounded-full", tradingStatus === "실행 중" ? "bg-safe" : tradingStatus === "중지됨" ? "bg-gain" : "bg-caution")} />
            {tradingStatus}
          </p>
          <p className="mt-1 text-xs text-slate-500">기본값은 모의투자 · 실제 주문 미연동입니다.</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="rounded-full border border-line bg-panelSoft p-2 text-slate-300" onClick={onPause} aria-label="일시정지">
            <Pause size={16} />
          </button>
          <button className="rounded-full bg-safe p-2 text-ink" onClick={onStart} aria-label="시작">
            <Play size={16} />
          </button>
        </div>
      </div>
      <div className="grid grid-cols-4 gap-2">
        <MiniMetric label="실행 중" value={`${strategies.filter((item) => item.status === "실행 중").length}`} />
        <MiniMetric label="오늘 신호" value="22" />
        <MiniMetric label="오늘 체결" value="9" />
        <MiniMetric label="실패" value="0" />
      </div>
      <button
        className="mt-3 flex w-full items-center justify-between rounded-xl border border-gain/45 bg-gain/15 p-4 text-left text-gain"
        onClick={onKill}
      >
        <span>
          <span className="block text-sm font-semibold">Kill Switch · 전체 즉시 중지</span>
          <span className="text-xs">모든 전략 정지 · 대기 주문 취소 (데모)</span>
        </span>
        <Power size={20} />
      </button>
    </Panel>
  );
}

function AssetCard() {
  const dayPnl = strategyDailyPnl.at(-1)?.total ?? accountSnapshot.dailyPnl;

  return (
    <section className="overflow-hidden rounded-2xl border border-line bg-panel">
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-slate-400">평가자산</p>
            <p className="mt-1 text-3xl font-bold">{formatMoney(accountSnapshot.totalAsset)}원</p>
          </div>
          <div className="text-right text-gain">
            <p className="text-lg font-bold">{signedPct(accountSnapshot.dailyPnlPercent)}</p>
            <p className="text-xs">+{formatMoney(accountSnapshot.dailyPnl)}원</p>
          </div>
        </div>
        <div className="mt-5 grid grid-cols-3 overflow-hidden rounded-xl border border-line">
          <AssetMetric label="누적 손익" value={`+${formatMoney(accountSnapshot.cumulativePnl)}원`} tone="text-gain" />
          <AssetMetric label="현금" value={`${(accountSnapshot.cash / 10000).toFixed(1)}만`} />
          <AssetMetric label="현금 비중" value={`${accountSnapshot.cashRatio}%`} />
        </div>
      </div>
      <div className="h-20 border-t border-line bg-gradient-to-b from-gain/20 to-gain/5">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={strategyDailyPnl}>
            <Area dataKey="total" stroke="#ef4444" fill="#ef444433" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <div className="grid grid-cols-4 gap-px border-t border-line bg-line text-center">
        {[
          ["눌림", strategyDailyPnl.at(-1)?.pullback ?? 0],
          ["급등주", strategyDailyPnl.at(-1)?.momentum ?? 0],
          ["스캘핑", strategyDailyPnl.at(-1)?.scalping ?? 0],
          ["최종", dayPnl],
        ].map(([label, value]) => (
          <div key={String(label)} className="bg-panel px-2 py-2">
            <p className="text-[10px] text-slate-500">{label}</p>
            <p className={cx("mt-0.5 text-[11px] font-semibold", Number(value) >= 0 ? "text-gain" : "text-loss")}>{formatSignedMoney(Number(value))}원</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function StrategyPnlChart() {
  return (
    <div>
      <div className="h-44">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={strategyDailyPnl}>
            <XAxis dataKey="date" tick={{ fill: "#94a3b8", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis hide domain={["dataMin - 50000", "dataMax + 50000"]} />
            <Tooltip
              contentStyle={{ background: "#101a20", border: "1px solid #23333d", borderRadius: 10 }}
              formatter={(value: number, name: string) => [`${formatSignedMoney(value)}원`, strategyLabel(name)]}
            />
            <Line type="monotone" dataKey="pullback" stroke="#14b8a6" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="momentum" stroke="#ef4444" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="scalping" stroke="#3b82f6" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="total" stroke="#f59e0b" strokeWidth={2.5} dot />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <LegendItem color="bg-safe" label="매매 전략 1번(눌림)" value={formatSignedMoney(strategyDailyPnl.at(-1)?.pullback ?? 0)} />
        <LegendItem color="bg-gain" label="매매 전략 2번(급등주)" value={formatSignedMoney(strategyDailyPnl.at(-1)?.momentum ?? 0)} />
        <LegendItem color="bg-loss" label="매매 전략 3번(스캘핑)" value={formatSignedMoney(strategyDailyPnl.at(-1)?.scalping ?? 0)} />
        <LegendItem color="bg-caution" label="최종 손익" value={formatSignedMoney(strategyDailyPnl.at(-1)?.total ?? 0)} />
      </div>
    </div>
  );
}

function AiWatchStrip({ onSelectPair }: { onSelectPair: (pairId: string) => void }) {
  const grouped = useMemo(
    () => ({
      candidates: aiWatchCandidates.filter((item) => item.status === "진입 후보"),
      watching: aiWatchCandidates.filter((item) => item.status === "감시"),
    }),
    [],
  );

  return (
    <div className="space-y-4">
      <AiWatchRow title="진입 후보" items={grouped.candidates} onSelectPair={onSelectPair} />
      <AiWatchRow title="감시" items={grouped.watching} onSelectPair={onSelectPair} />
    </div>
  );
}

function AiWatchRow({
  title,
  items,
  onSelectPair,
}: {
  title: string;
  items: typeof aiWatchCandidates;
  onSelectPair: (pairId: string) => void;
}) {
  return (
    <div>
      <p className="mb-2 text-xs font-semibold text-slate-300">{title}</p>
      <div className="flex gap-3 overflow-x-auto pb-1 no-scrollbar">
        {items.map((item) => (
          <button
            key={item.id}
            className="min-w-[260px] rounded-2xl border border-white/10 bg-white/[0.04] p-4 text-left shadow-[inset_0_1px_0_rgba(255,255,255,0.08)] backdrop-blur"
            onClick={() => onSelectPair(item.pairId)}
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-sm font-bold">{item.symbolName}</p>
                <p className="text-xs text-slate-500">{item.symbol} · {item.strategyName}</p>
              </div>
              <Badge
                label={item.status}
                className={item.status === "진입 후보" ? "border-safe/40 bg-safe/15 text-safe" : "border-caution/40 bg-caution/15 text-caution"}
              />
            </div>
            <p className={cx("mt-3 text-lg font-bold", item.changePercent >= 0 ? "text-gain" : "text-loss")}>
              {signedPct(item.changePercent)}
            </p>
            <p className="mt-2 text-xs leading-5 text-slate-400">AI 감시 이유: {item.reason}</p>
          </button>
        ))}
      </div>
    </div>
  );
}

function HomeActiveStrategies() {
  return (
    <Panel title="활성 전략" action="전체보기">
      <div className="mb-3 grid grid-cols-3 gap-2">
        <MiniMetric label="실행 중" value="1" />
        <MiniMetric label="오늘 신호" value="22" />
        <MiniMetric label="오늘 체결" value="9" />
      </div>
      <div className="space-y-2">
        {strategies.slice(0, 3).map((strategy) => (
          <div key={strategy.id} className="flex items-center justify-between rounded-xl border border-line bg-panelSoft px-3 py-3">
            <div className="min-w-0">
              <Badge label={strategy.status} className={statusCopy[strategy.status]} />
              <p className="mt-2 truncate text-sm font-semibold">{strategy.name}</p>
              <p className="mt-1 truncate text-xs text-slate-500">{strategy.market}</p>
            </div>
            <p className={cx("ml-3 shrink-0 text-sm font-bold", strategy.pnlPercent >= 0 ? "text-gain" : "text-loss")}>
              {signedPct(strategy.pnlPercent)}
            </p>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function HomeWatchSummary({ onSelectPair }: { onSelectPair: (pairId: string) => void }) {
  const candidate = watchPairs[0];

  return (
    <Panel title="실시간 감시 종목" subtitle="대장주·후속주 반응 지연 추적" action="AI 감시">
      <button className="w-full rounded-xl border border-white/10 bg-white/[0.035] p-3 text-left backdrop-blur" onClick={() => onSelectPair(candidate.id)}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs text-slate-500">대장주: {candidate.leaderName}</p>
            <p className="mt-1 text-sm font-semibold">후속주: {candidate.followerName}</p>
          </div>
          <Badge label={candidate.status} className="border-safe/40 bg-safe/15 text-safe" />
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <MiniMetric label="반응 지연" value={`${candidate.lagPercent.toFixed(1)}%`} tone="safe" />
          <MiniMetric label="호가 불균형" value={`${candidate.bidAskImbalance.toFixed(2)}x`} tone="safe" />
        </div>
        <p className="mt-3 text-xs leading-5 text-slate-400">AI 감시 이유: 대장주 급등 대비 후속주 반응 지연, 거래대금 증가, 매수 호가 우위 동시 발생</p>
      </button>
      <div className="mt-3">
        <HybridOpsPanel compact />
      </div>
    </Panel>
  );
}

function LegendItem({ color, label, value }: { color: string; label: string; value: string }) {
  return (
    <div className="rounded-xl border border-line bg-panelSoft p-3">
      <p className="flex items-center gap-2 text-[11px] text-slate-400"><span className={cx("h-2 w-2 rounded-full", color)} />{label}</p>
      <p className={cx("mt-1 text-sm font-semibold", value.startsWith("-") ? "text-loss" : "text-gain")}>{value}원</p>
    </div>
  );
}

function WatchScreen({ onSelectPair }: { onSelectPair: (pairId: string) => void }) {
  const [filter, setFilter] = useState("전체");
  const [query, setQuery] = useState("");
  const filtered = (filter === "전체" ? watchPairs : watchPairs.filter((pair) => pair.group === filter)).filter((pair) => {
    if (!query.trim()) return true;
    return [pair.leaderName, pair.leaderSymbol, pair.followerName, pair.followerSymbol].some((value) => value.includes(query.trim()));
  });
  return (
    <div className="space-y-4">
      <p className="rounded-xl border border-safe/30 bg-safe/10 px-3 py-2 text-xs text-safe">
        장중 · REST/WebSocket 어댑터 준비 · 데이터 지연 0.3초 · 모의투자
      </p>
      <label className="flex items-center gap-2 rounded-2xl border border-line bg-panel px-3 py-3">
        <Search size={18} className="text-slate-500" />
        <input
          className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-slate-600"
          placeholder="종목명/종목코드 검색 · 코스피/코스닥 전종목 서버 동기화 예정"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
        />
      </label>
      <Segmented labels={themeCategories.map((item) => item.label)} active={filter} onChange={setFilter} />
      <Panel title="전종목 카테고리화 계획" subtitle="키움 REST 시세/차트와 조건검색을 서버에서 동기화한 뒤, 웹/내부 분류를 합쳐 짝궁매매 그룹으로 확장합니다.">
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {themeCategories.slice(1).map((item) => (
            <div key={item.id} className="min-w-[140px] rounded-xl border border-line bg-panelSoft p-3">
              <p className="text-xs font-semibold">{item.label}</p>
              <p className="mt-1 text-[11px] leading-4 text-slate-500">{item.description}</p>
            </div>
          ))}
        </div>
      </Panel>
      <div className="space-y-3">
        {filtered.map((pair) => (
          <button key={pair.id} className="w-full text-left" onClick={() => onSelectPair(pair.id)}>
            <Panel title={`${pair.leaderName} → ${pair.followerName}`} action={`${pair.score} / 100`}>
              <PairSummary pair={pair} />
            </Panel>
          </button>
        ))}
      </div>
    </div>
  );
}

function WatchDetailScreen({ pair, onBack }: { pair: PairWatchlist; onBack: () => void }) {
  const realtime = useRealtimeMarket(pair.followerSymbol);
  const signal = realtime.signal;
  const pairTimeline = tradeTimelines.filter((item) => item.symbol === pair.followerSymbol || item.symbol === pair.leaderSymbol);
  return (
    <div className="space-y-4">
      <BackTitle title={`${pair.followerName} 상세`} onBack={onBack} />
      <p className="rounded-xl border border-safe/30 bg-safe/10 px-3 py-2 text-xs text-safe">
        실시간 Mock 스트림 연결됨 · 데이터 지연 {realtime.latencyMs}ms · {new Date(realtime.updatedAt).toLocaleTimeString("ko-KR")}
      </p>
      <Panel title={`${pair.leaderName} 대비 후속주`} action={pair.status}>
        <div className="grid grid-cols-2 gap-2">
          <MiniMetric label="현재가" value={`${formatMoney(signal.price)}원`} />
          <MiniMetric label="등락률" value={signedPct(signal.changePercent)} tone="gain" />
          <MiniMetric label="거래대금" value={`${Math.round(signal.turnoverKrw / 100000000)}억`} />
          <MiniMetric label="체결강도" value={`${signal.tradeStrength}%`} tone="safe" />
        </div>
      </Panel>
      <Panel title="키움형 통합 차트" subtitle="1분/3분/5분 전환 · 캔들/거래량 데모">
        <KiwoomStyleChart signal={signal} />
      </Panel>
      <Panel title="호가 · 체결 · AI 수급 통합창" subtitle="호가 5단계와 체결 흐름을 한 화면에서 확인">
        <div className="grid grid-cols-[1fr_120px] gap-3">
          <OrderBook rows={signal.orderBook} />
          <ExecutionTape executions={signal.executions} />
        </div>
        <AiSupplyBlocks pair={pair} />
      </Panel>
      <Panel title="전략 신호 요약" action={`${pair.score}점`}>
        <div className="space-y-2 text-sm">
          <Row left="반응 지연률" right={`${pair.lagPercent.toFixed(1)}%`} tone="safe" />
          <Row left="거래대금 증가" right={`${pair.turnoverRatio5m.toFixed(1)}배`} tone="safe" />
          <Row left="호가 불균형" right={`매수 우위 ${pair.bidAskImbalance.toFixed(2)}배`} tone="safe" />
          <Row left="프로그램 매매" right={pair.programSignal} tone="safe" />
          <Row left="연결 전략" right={strategies.find((item) => item.id === pair.linkedStrategyId)?.name ?? "-"} />
        </div>
      </Panel>
      <Panel title="6개월 매매 타임라인" subtitle="홈 타임라인과 동일한 종목별 신호 → 주문 → 체결 → 손익 흐름">
        <TradeTimelineList items={pairTimeline.length ? pairTimeline : signal.sixMonthTimeline} />
      </Panel>
    </div>
  );
}

function StrategiesScreen({
  onOpenBuilder,
  onOpenDetail,
}: {
  onOpenBuilder: () => void;
  onOpenDetail: (strategyId: string) => void;
}) {
  const [deleteTarget, setDeleteTarget] = useState<Strategy | null>(null);
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">전략</h1>
        <button className="flex items-center gap-2 rounded-full bg-safe px-4 py-2 text-sm font-semibold text-ink" onClick={onOpenBuilder}>
          <Plus size={16} /> 전략 생성
        </button>
      </div>
      <Segmented labels={["전체 4", "실행 중 1", "대기 1", "일시정지 1", "오류 1"]} active="전체 4" onChange={() => undefined} />
      {strategies.map((strategy) => {
        const pair = watchPairs.find((item) => item.id === strategy.pairId);
        return (
          <Panel key={strategy.id} title={strategy.name} action={signedPct(strategy.pnlPercent)}>
            <div className="mb-3 flex items-center justify-between">
              <Badge label={strategy.status} className={statusCopy[strategy.status]} />
              <button className="text-xs text-slate-300" onClick={() => onOpenDetail(strategy.id)}>상세 <ChevronRight className="inline" size={14} /></button>
            </div>
            <p className="text-xs text-slate-400">{strategy.market}</p>
            <p className="mt-2 text-xs text-slate-400">짝궁 그룹: {pair?.leaderName} → {pair?.followerName}</p>
            <div className="mt-3 grid grid-cols-3 gap-2">
              <MiniMetric label="신호" value={`${strategy.todaySignals}`} />
              <MiniMetric label="체결" value={`${strategy.todayFills}`} />
              <MiniMetric label="마지막 신호" value={strategy.lastSignalAgo} />
            </div>
            <div className="mt-3 text-xs text-slate-400">
              오늘 사용 금액: {formatMoney(strategy.capitalUsed)}원 / {formatMoney(strategy.capitalLimit)}원 · 현재 보유: {strategy.currentHolding ?? "없음"}
            </div>
            {strategy.status === "오류" ? (
              <div className="mt-3 grid grid-cols-3 gap-2">
                <SmallButton label="오류 원인" icon={AlertTriangle} />
                <SmallButton label="재연결" icon={RefreshCw} />
                <SmallButton label="수정" icon={Settings} />
              </div>
            ) : (
              <div className="mt-3 grid grid-cols-4 gap-2">
                <SmallButton label="실행" icon={Play} />
                <SmallButton label="일시정지" icon={Pause} />
                <SmallButton label="복제" icon={Copy} />
                <SmallButton label="삭제" icon={Trash2} onClick={() => setDeleteTarget(strategy)} danger />
              </div>
            )}
          </Panel>
        );
      })}
      {deleteTarget ? (
        <ConfirmModal
          title="전략 삭제"
          body={`${deleteTarget.name} 전략을 데모 목록에서 삭제하시겠습니까? 실제 주문 데이터는 변경되지 않습니다.`}
          action="삭제"
          onClose={() => setDeleteTarget(null)}
          onConfirm={() => setDeleteTarget(null)}
        />
      ) : null}
    </div>
  );
}

function StrategyDetailScreen({ strategy, onBack }: { strategy: Strategy; onBack: () => void }) {
  const [detailTab, setDetailTab] = useState("운영");
  return (
    <div className="space-y-4">
      <BackTitle title={strategy.name} onBack={onBack} />
      <Segmented labels={["운영", "조건", "성과 분석", "주문 기록", "설정"]} active={detailTab} onChange={setDetailTab} />
      {detailTab === "운영" ? (
        <Panel title="운영 상태" action={strategy.status}>
          <div className="grid grid-cols-2 gap-2">
            <MiniMetric label="오늘 신호" value={`${strategy.todaySignals}`} />
            <MiniMetric label="오늘 체결" value={`${strategy.todayFills}`} />
            <MiniMetric label="사용 금액" value={`${formatMoney(strategy.capitalUsed)}원`} />
            <MiniMetric label="최대 투자금" value={`${formatMoney(strategy.capitalLimit)}원`} />
          </div>
        </Panel>
      ) : null}
      {detailTab === "조건" ? <ConditionBlocks /> : null}
      {detailTab === "성과 분석" ? <AnalyticsScreen /> : null}
      {detailTab === "주문 기록" ? <OrdersScreen compact /> : null}
      {detailTab === "설정" ? (
        <Panel title="전략 설정">
          <Row left="손절" right="-1.5%" tone="loss" />
          <Row left="익절" right="+3%" tone="gain" />
          <Row left="최대 보유" right="5분" />
          <Row left="일일 진입" right="1회" />
        </Panel>
      ) : null}
    </div>
  );
}

function StrategyBuilderScreen({
  converted,
  onConvert,
  onBack,
}: {
  converted: boolean;
  onConvert: () => void;
  onBack: () => void;
}) {
  return (
    <div className="space-y-4">
      <BackTitle title="AI 전략 빌더" onBack={onBack} />
      <Panel title="자연어 전략 입력" subtitle="AI는 자동 주문을 결정하지 않고, 자연어를 규칙형 전략으로 정리하는 보조 기능입니다.">
        <textarea
          className="min-h-40 w-full resize-none rounded-xl border border-line bg-ink p-3 text-sm leading-6 text-slate-100 outline-none focus:border-safe"
          defaultValue={"대장주가 1분 내 2% 이상 상승하고,\n거래대금이 최근 5분 평균의 2배 이상이며,\n후속주가 대장주보다 0.8% 이상 덜 상승했고,\n매수 호가 잔량이 매도 호가 잔량보다 1.3배 이상일 때\n1회 매수한다.\n손절은 -1.5%, 익절은 +3%, 최대 보유시간은 5분으로 설정한다."}
        />
        <button className="mt-3 w-full rounded-xl bg-safe px-4 py-3 text-sm font-semibold text-ink" onClick={onConvert}>
          저장 및 모의 시뮬레이션
        </button>
      </Panel>
      <Panel title="전략 구성">
        <div className="space-y-2">
          {["전략 이름", "대상 종목 그룹", "대장주 조건", "후속주 반응 지연 조건", "거래대금 조건", "호가 불균형 조건", "체결강도 조건", "프로그램/기관/외국인 보조 신호", "손절/익절", "최대 보유 시간", "일일 주문 횟수 제한", "최대 투자금"].map((label, index) => (
            <Row key={label} left={`${index + 1}. ${label}`} right="데모 설정" />
          ))}
        </div>
      </Panel>
      {converted ? <ConditionBlocks /> : null}
    </div>
  );
}

function OrdersScreen({ onReason, compact }: { onReason?: (order: Order) => void; compact?: boolean }) {
  return (
    <div className="space-y-4">
      {!compact ? (
        <>
          <h1 className="text-xl font-bold">주문 · 체결</h1>
          <p className="rounded-xl border border-caution/40 bg-caution/10 px-3 py-3 text-xs text-caution">
            수동 주문은 안전을 위해 비활성화되어 있습니다. 모든 주문은 전략 신호와 리스크 검증 이후 생성됩니다. (데모)
          </p>
          <div className="grid grid-cols-4 gap-2">
            <MiniMetric label="미체결" value="1건" />
            <MiniMetric label="부분 체결" value="1건" />
            <MiniMetric label="오늘 체결" value="9건" />
            <MiniMetric label="실패" value="0건" />
          </div>
        </>
      ) : null}
      {orders.map((order) => (
        <Panel key={order.id} title={`${order.symbolName} ${order.side}`} action={order.status}>
          <div className="grid grid-cols-2 gap-2">
            <MiniMetric label="종목코드" value={order.symbol} />
            <MiniMetric label="연결 전략" value={order.strategyName} />
            <MiniMetric label="주문 수량" value={`${order.quantity}주`} />
            <MiniMetric label="주문 가격" value={`${formatMoney(order.price)}원`} />
            <MiniMetric label="체결/잔량" value={`${order.filledQuantity}/${order.remainingQuantity}`} />
            <MiniMetric label="경과" value={order.elapsed} />
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button className="rounded-xl border border-line bg-panelSoft px-3 py-3 text-sm font-semibold" onClick={() => onReason?.(order)}>
              주문 근거 보기
            </button>
            <button className="rounded-xl border border-line bg-ink px-3 py-3 text-sm text-slate-500" disabled>
              {order.cancelable ? "취소 가능" : "취소 불가"}
            </button>
          </div>
        </Panel>
      ))}
    </div>
  );
}

function AnalyticsScreen() {
  return (
    <div className="space-y-4">
      <Panel title="실현 손익" subtitle="기간 · 7일 (데모)">
        <p className="text-3xl font-bold text-gain">+{formatMoney(analytics.realizedPnl)}원</p>
        <div className="mt-4 grid grid-cols-3 gap-2">
          <MiniMetric label="승률" value={`${analytics.winRate}%`} />
          <MiniMetric label="평균 익절" value={`${formatMoney(analytics.averageProfit)}원`} tone="gain" />
          <MiniMetric label="평균 손절" value={`${formatMoney(analytics.averageLoss)}원`} tone="loss" />
          <MiniMetric label="MDD" value={`${formatMoney(analytics.mdd)}원`} tone="loss" />
          <MiniMetric label="평균 보유" value={`${analytics.averageHoldingMinutes}분`} />
          <MiniMetric label="체결 수" value={`${analytics.fillCount}건`} />
        </div>
      </Panel>
      <Panel title="전략별 기여도">
        <ContributionBars items={analytics.strategyContribution} />
      </Panel>
      <Panel title="짝궁 그룹별 성과">
        {analytics.pairPerformance.map((item) => (
          <Row key={item.label} left={item.label} right={`${formatMoney(item.pnl)}원 · 승률 ${item.winRate}%`} tone={item.pnl >= 0 ? "gain" : "loss"} />
        ))}
      </Panel>
      <Panel title="신호 점수 구간별 승률">
        {analytics.scoreBuckets.map((item) => (
          <Row key={item.label} left={item.label} right={`${item.winRate}%`} tone="safe" />
        ))}
      </Panel>
      <Panel title="시간대별 체결 성과">
        <div className="h-36">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={analytics.hourlyPerformance}>
              <XAxis dataKey="hour" tick={{ fill: "#94a3b8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Bar dataKey="fills" fill="#22c78a" radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Panel>
      <Panel title="손실 원인 태그">
        {analytics.lossTags.map((item) => (
          <Row key={item.label} left={item.label} right={`${item.count}건`} tone="gain" />
        ))}
      </Panel>
    </div>
  );
}

function SettingsScreen({ settings, onChange }: { settings: RiskSettings; onChange: (settings: RiskSettings) => void }) {
  const [kiwoomStatus, setKiwoomStatus] = useState<KiwoomConnectionStatus | null>(null);
  const [kiwoomLoading, setKiwoomLoading] = useState(false);
  const [brokerForm, setBrokerForm] = useState({
    appKey: "",
    secretKey: "",
    accountNo: "",
    fixedIp: "",
    sampleReceived: false,
  });
  const [setupResult, setSetupResult] = useState<{
    ok: boolean;
    message: string;
    missing: string[];
    nextSteps: string[];
    sampleStatus: string;
    accountNoMasked: string;
    appKeyLast4: string;
    storageProvider: string;
    stored: boolean;
  } | null>(null);
  const [realtimeStatus, setRealtimeStatus] = useState<{
    provider: string;
    mode: string;
    connected: boolean;
    latencyMs: number;
    symbol: string;
    price: number;
    statusMessage: string;
    requiredForKiwoom: string[];
  } | null>(null);

  function setNumber(key: keyof Pick<RiskSettings, "dailyLossLimit" | "strategyCapitalLimit" | "symbolMaxWeightPercent" | "maxOpenPositions" | "dailyOrderLimit">, raw: string) {
    onChange({ ...settings, [key]: Number(raw.replace(/[^\d]/g, "")) || 0 });
  }
  function toggle(key: keyof RiskSettings["alerts"]) {
    onChange({ ...settings, alerts: { ...settings.alerts, [key]: !settings.alerts[key] } });
  }
  async function checkKiwoom(action: "status" | "login") {
    setKiwoomLoading(true);
    try {
      setKiwoomStatus(
        await apiFetch<KiwoomConnectionStatus>(`/api/kiwoom/${action}`, {
          method: action === "login" ? "POST" : "GET",
        }),
      );
    } finally {
      setKiwoomLoading(false);
    }
  }
  async function validateBrokerSetup() {
    setKiwoomLoading(true);
    try {
      setSetupResult(
        await apiFetch("/api/kiwoom/setup", {
          method: "POST",
          body: JSON.stringify(brokerForm),
          headers: { "Content-Type": "application/json" },
        }),
      );
    } finally {
      setKiwoomLoading(false);
    }
  }
  async function checkRealtimeStatus() {
    setKiwoomLoading(true);
    try {
      setRealtimeStatus(await apiFetch("/api/realtime/status"));
    } finally {
      setKiwoomLoading(false);
    }
  }

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold">리스크 · 설정</h1>
      <Panel title="리스크 한도" subtitle="자동매매가 절대 넘지 않는 안전 한도">
        <MoneyInput label="일일 손실 한도" value={settings.dailyLossLimit} suffix="원" onChange={(value) => setNumber("dailyLossLimit", value)} />
        <MoneyInput label="전략별 최대 투자금" value={settings.strategyCapitalLimit} suffix="원" onChange={(value) => setNumber("strategyCapitalLimit", value)} />
        <MoneyInput label="종목당 최대 비중" value={settings.symbolMaxWeightPercent} suffix="%" onChange={(value) => setNumber("symbolMaxWeightPercent", value)} />
        <MoneyInput label="동시 보유 종목 수" value={settings.maxOpenPositions} suffix="개" onChange={(value) => setNumber("maxOpenPositions", value)} />
        <MoneyInput label="일일 주문 횟수 제한" value={settings.dailyOrderLimit} suffix="건" onChange={(value) => setNumber("dailyOrderLimit", value)} />
        <p className="mt-3 rounded-xl border border-safe/35 bg-safe/10 p-3 text-xs text-safe">
          현재 한도 요약 · 일일 손실 {formatMoney(settings.dailyLossLimit)}원 · 종목당 {settings.symbolMaxWeightPercent}% 이하
        </p>
      </Panel>
      <Panel title="알림">
        <ToggleRow label="전략 오류" enabled={settings.alerts.strategyError} onClick={() => toggle("strategyError")} />
        <ToggleRow label="주문 실패" enabled={settings.alerts.orderFailure} onClick={() => toggle("orderFailure")} />
        <ToggleRow label="일일 손실 한도 도달" enabled={settings.alerts.dailyLossLimit} onClick={() => toggle("dailyLossLimit")} />
        <ToggleRow label="큰 수익/손실 발생" enabled={settings.alerts.largePnl} onClick={() => toggle("largePnl")} />
      </Panel>
      <Panel title="증권사 연동" subtitle="안전한 서버 측 연동만 지원합니다">
        <div className="rounded-xl border border-line bg-panelSoft p-4">
          <div className="flex items-center gap-3">
            <span className="rounded-full bg-safe/15 p-3 text-safe"><Link size={18} /></span>
            <div>
              <p className="text-sm font-semibold">키움증권</p>
              <p className="text-xs text-slate-400">REST API · 서버 환경변수 기반 로그인</p>
            </div>
            <Badge
              label={kiwoomStatus?.configured ? "키 설정됨" : "키 미설정"}
              className={cx("ml-auto", kiwoomStatus?.configured ? "border-safe/40 bg-safe/15 text-safe" : "border-caution/40 bg-caution/15 text-caution")}
            />
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button className="rounded-xl border border-line bg-ink px-3 py-3 text-sm" onClick={() => checkKiwoom("status")} disabled={kiwoomLoading}>
              API 키 확인
            </button>
            <button className="rounded-xl bg-safe px-3 py-3 text-sm font-semibold text-ink" onClick={() => checkKiwoom("login")} disabled={kiwoomLoading}>
              키움 로그인 시작
            </button>
          </div>
          <div className="mt-3 rounded-xl border border-caution/35 bg-caution/10 p-3 text-xs leading-5 text-caution">
            권장 방식: 앱에서 직접 보관하지 않고, AWS Secrets Manager 또는 서버 환경변수에 관리자만 등록합니다. 이 화면의 입력은 데모 검증용이며 저장되지 않습니다.
          </div>
          <div className="mt-3 grid gap-2">
            <BrokerSecretInput
              label="키움 API Key"
              value={brokerForm.appKey}
              placeholder="서버에 저장할 App Key"
              onChange={(value) => setBrokerForm((prev) => ({ ...prev, appKey: value }))}
            />
            <BrokerSecretInput
              label="키움 Secret Key"
              value={brokerForm.secretKey}
              placeholder="브라우저 저장 금지 · 서버 보관"
              secret
              onChange={(value) => setBrokerForm((prev) => ({ ...prev, secretKey: value }))}
            />
            <BrokerSecretInput
              label="증권 계좌번호"
              value={brokerForm.accountNo}
              placeholder="예: 0000000000"
              onChange={(value) => setBrokerForm((prev) => ({ ...prev, accountNo: value }))}
            />
            <BrokerSecretInput
              label="AWS 고정 IP"
              value={brokerForm.fixedIp}
              placeholder="키움 허용 IP 등록용 Elastic IP"
              onChange={(value) => setBrokerForm((prev) => ({ ...prev, fixedIp: value }))}
            />
            <button
              className="flex items-center justify-between rounded-xl border border-line bg-ink px-3 py-3 text-left text-sm"
              onClick={() => setBrokerForm((prev) => ({ ...prev, sampleReceived: !prev.sampleReceived }))}
            >
              <span>
                <span className="block font-semibold">실시간 응답 샘플 확보</span>
                <span className="text-xs text-slate-500">호가/체결/현재가 필드 매핑 확인용</span>
              </span>
              <span className={cx("rounded-full px-2 py-1 text-xs", brokerForm.sampleReceived ? "bg-safe/15 text-safe" : "bg-caution/15 text-caution")}>
                {brokerForm.sampleReceived ? "완료" : "필요"}
              </span>
            </button>
            <button className="rounded-xl bg-safe px-3 py-3 text-sm font-semibold text-ink" onClick={validateBrokerSetup} disabled={kiwoomLoading}>
              서버 보안 설정 검증 (데모)
            </button>
            <button className="rounded-xl border border-safe/40 bg-safe/10 px-3 py-3 text-sm font-semibold text-safe" onClick={checkRealtimeStatus} disabled={kiwoomLoading}>
              실시간 시세 연결 테스트
            </button>
          </div>
          {setupResult ? (
            <div className="mt-3 rounded-xl border border-line bg-ink p-3 text-xs leading-5 text-slate-300">
              <p className={setupResult.ok ? "text-safe" : "text-caution"}>{setupResult.message}</p>
              <p className="mt-1 text-slate-500">
                저장소: {setupResult.storageProvider} · 저장 여부: {setupResult.stored ? "완료" : "미저장"} · App Key 끝 4자리: {setupResult.appKeyLast4 || "-"} · 계좌: {setupResult.accountNoMasked || "-"} · {setupResult.sampleStatus}
              </p>
              {setupResult.missing.length ? <p className="mt-1 text-caution">필수 누락: {setupResult.missing.join(", ")}</p> : null}
              <div className="mt-2 space-y-1">
                {setupResult.nextSteps.map((step) => (
                  <p key={step} className="text-[11px] text-slate-500">· {step}</p>
                ))}
              </div>
            </div>
          ) : null}
          {realtimeStatus ? (
            <div className="mt-3 rounded-xl border border-line bg-ink p-3 text-xs leading-5 text-slate-300">
              <p className={realtimeStatus.connected ? "text-safe" : "text-caution"}>
                실시간 상태: {realtimeStatus.provider} · {realtimeStatus.mode} · {realtimeStatus.connected ? "연결됨" : "대기/미연결"}
              </p>
              <p className="mt-1 text-slate-500">
                {realtimeStatus.symbol} · {formatMoney(realtimeStatus.price)}원 · 지연 {realtimeStatus.latencyMs}ms
              </p>
              <p className="mt-1 text-slate-500">{realtimeStatus.statusMessage}</p>
              {realtimeStatus.provider !== "kiwoom" || !realtimeStatus.connected ? (
                <div className="mt-2 space-y-1">
                  {realtimeStatus.requiredForKiwoom.map((item) => (
                    <p key={item} className="text-[11px] text-slate-500">· {item}</p>
                  ))}
                </div>
              ) : null}
            </div>
          ) : null}
          {kiwoomStatus ? (
            <div className="mt-3 rounded-xl border border-line bg-ink p-3 text-xs leading-5 text-slate-300">
              <p>{kiwoomStatus.message}</p>
              <p className="mt-1 text-slate-500">사용 범위: {kiwoomStatus.availableScopes.join(" · ")}</p>
              {kiwoomStatus.missingEnv.length ? <p className="mt-1 text-caution">누락: {kiwoomStatus.missingEnv.join(", ")}</p> : null}
            </div>
          ) : null}
        </div>
        <p className="mt-3 rounded-xl border border-line bg-ink p-3 text-xs leading-5 text-slate-400">
          API 키와 시크릿은 프론트엔드에 저장되지 않습니다. 실제 주문 실행은 서버 측 자동매매 엔진에서만 처리됩니다.
        </p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <MiniMetric label="권장 운영" value="AWS Secrets" tone="safe" />
          <MiniMetric label="실시간" value="서버 WebSocket" tone="safe" />
          <MiniMetric label="브라우저 저장" value="금지" tone="caution" />
          <MiniMetric label="실계좌 전환" value="별도 승인" tone="caution" />
        </div>
      </Panel>
      <Panel title="서버 상태">
        <Row left="시세 어댑터" right="정상 (데모)" tone="safe" />
        <Row left="주문 워커" right="연결됨 (데모)" tone="safe" />
        <Row left="Python 분석 워커" right="분석 전용 · 주문 불가" tone="safe" />
        <Row left="최종 주문 게이트" right="Node 엔진" tone="safe" />
        <Row left="데이터 동기화" right="0.3초 전" tone="safe" />
        <Row left="앱 버전" right="prototype" />
      </Panel>
      <button className="w-full rounded-xl bg-safe px-4 py-3 text-sm font-semibold text-ink">설정 저장</button>
      <p className="pb-4 text-center text-xs text-slate-500">본 화면은 데모 프로토타입입니다. 실주문 · 실로그인은 포함되지 않습니다.</p>
    </div>
  );
}

function PairSummary({ pair }: { pair: PairWatchlist }) {
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <MiniMetric label={`대장주: ${pair.leaderName}`} value={signedPct(pair.leaderChangePercent)} tone="gain" />
        <MiniMetric label={`후속주: ${pair.followerName}`} value={signedPct(pair.followerChangePercent)} tone="gain" />
        <MiniMetric label="반응 지연" value={`${pair.lagPercent.toFixed(1)}%`} tone="safe" />
        <MiniMetric label="거래대금" value={`${pair.turnoverRatio5m.toFixed(1)}배`} />
        <MiniMetric label="호가 불균형" value={`매수 우위 ${pair.bidAskImbalance.toFixed(2)}x`} tone="safe" />
        <MiniMetric label="상태" value={pair.status} tone={statusTone(pair.status)} />
      </div>
      <div className="rounded-xl border border-line bg-ink p-3 text-xs leading-5 text-slate-300">
        프로그램: {pair.programSignal} · 기관/외국인: {pair.institutionSignal} / {pair.foreignSignal}
      </div>
    </div>
  );
}

function ConditionBlocks() {
  const blocks = ["대장주 1분 상승률 ≥ 2%", "후속주 반응 지연률 ≥ 0.8%", "거래대금 증가율 ≥ 2배", "호가 불균형 ≥ 1.3", "손절 -1.5%", "익절 +3%", "최대 보유 5분", "일일 진입 횟수 1회"];
  return (
    <Panel title="조건 블록 변환 결과" action="데모">
      <div className="grid grid-cols-1 gap-2">
        {blocks.map((block) => (
          <div key={block} className="rounded-xl border border-safe/25 bg-safe/10 px-3 py-2 text-sm text-safe">
            {block}
          </div>
        ))}
      </div>
    </Panel>
  );
}

function Timeline({ onSelectPair }: { onSelectPair: (pairId: string) => void }) {
  const items = tradeTimelines.filter((item) => item.date === "2026-06-30");
  return (
    <div className="space-y-3">
      {items.map((item) => (
        <button key={item.id} className="w-full rounded-2xl border border-line bg-panelSoft p-3 text-left" onClick={() => onSelectPair(pairFromSymbol(item.symbol))}>
          <div className="mb-3 flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold">{item.symbolName}</p>
              <p className="text-xs text-slate-500">{item.symbol} · {item.date}</p>
            </div>
            <ChevronRight size={16} className="text-slate-500" />
          </div>
          <div className="grid grid-cols-4 gap-2">
            {item.steps.map((step) => (
              <div key={step.label} className="rounded-xl bg-ink p-2">
                <p className="text-[11px] text-slate-500">{step.label}</p>
                <p className={cx("mt-1 text-[11px] font-semibold leading-4", step.tone === "gain" && "text-gain", step.tone === "loss" && "text-loss", step.tone === "safe" && "text-safe", step.tone === "caution" && "text-caution")}>
                  {step.value}
                </p>
              </div>
            ))}
          </div>
        </button>
      ))}
    </div>
  );
}

function HybridOpsPanel({ compact }: { compact?: boolean }) {
  const items = [
    { label: "Node 엔진", value: "시세 수신 · 리스크 검증 · 주문 게이트", tone: "safe" as const },
    { label: "Python 워커", value: "백테스트 · AI 점수 · 후보군 분석", tone: "caution" as const },
    { label: "보안 경계", value: "Python 주문 권한 없음 · 시크릿 서버 보관", tone: "safe" as const },
  ];

  if (compact) {
    return (
      <div className="rounded-xl border border-line bg-ink p-3">
        <p className="text-xs font-semibold text-slate-300">하이브리드 운영</p>
        <p className="mt-1 text-[11px] leading-4 text-slate-500">실시간 실행은 Node, 분석 보조는 Python. Python은 주문 권한 없음.</p>
      </div>
    );
  }

  return (
    <Panel title="하이브리드 운영 구조" subtitle="실시간 실행은 Node, 분석 보조는 Python">
      <div className="grid gap-2">
        {items.map((item) => (
          <div key={item.label} className="flex items-center justify-between gap-3 rounded-xl border border-line bg-panelSoft p-3">
            <div>
              <p className="text-xs font-semibold text-slate-200">{item.label}</p>
              <p className="mt-1 text-[11px] leading-4 text-slate-500">{item.value}</p>
            </div>
            <span className={cx("h-2.5 w-2.5 shrink-0 rounded-full", item.tone === "safe" ? "bg-safe" : "bg-caution")} />
          </div>
        ))}
      </div>
    </Panel>
  );
}

function MarketSummary() {
  const [summary, setSummary] = useState<MarketSummarySnapshot>(marketSummarySnapshot);

  useEffect(() => {
    let mounted = true;
    apiFetch<MarketSummarySnapshot>("/api/market/summary")
      .then((data) => {
        if (mounted) setSummary(data);
      })
      .catch(() => undefined);

    return () => {
      mounted = false;
    };
  }, []);

  return (
    <Panel title="시장 종합" subtitle={`지수 · 환율 · 선물 · AI 시황 (${summary.updatedAt})`}>
      <div className="grid grid-cols-3 gap-2">
        {summary.indexes.map((quote) => (
          <MarketQuoteCard key={quote.id} quote={quote} />
        ))}
      </div>
      <div className="mt-3">
        <p className="mb-2 text-xs font-semibold text-slate-300">선물</p>
        <div className="grid grid-cols-3 gap-2">
          {summary.futures.map((quote) => (
            <MarketQuoteCard key={quote.id} quote={quote} compact />
          ))}
        </div>
        <p className="mt-2 text-[11px] leading-4 text-slate-500">
          해외 선물은 24시간에 가까운 외부 피드가 필요합니다. 국내 선물은 거래소 세션 기준으로 처리합니다.
        </p>
      </div>
      <div className="mt-4 grid gap-2">
        <MarketInsightCard insight={summary.kospiNewsInsight} />
        <MarketInsightCard insight={summary.kosdaqNewsInsight} />
        <MarketInsightCard insight={summary.kospiFlowInsight} />
        <MarketInsightCard insight={summary.kosdaqFlowInsight} />
        <MarketInsightCard insight={summary.usLiveInsight} />
      </div>
      <div className="mt-4 rounded-xl border border-safe/30 bg-safe/10 p-3">
        <p className="text-xs font-semibold text-safe">전략 기초 필터</p>
        <div className="mt-2 space-y-1">
          {summary.strategyBase.map((item) => (
            <p key={item} className="text-[11px] leading-5 text-slate-300">· {item}</p>
          ))}
        </div>
      </div>
      <div className="mt-3 rounded-xl border border-line bg-ink p-3">
        <p className="text-xs font-semibold text-slate-300">데이터 연동 메모</p>
        <div className="mt-2 space-y-1">
          {summary.providerNotes.map((item) => (
            <p key={item} className="text-[11px] leading-5 text-slate-500">· {item}</p>
          ))}
        </div>
      </div>
    </Panel>
  );
}

function MarketQuoteCard({ quote, compact }: { quote: MarketIndexQuote; compact?: boolean }) {
  return (
    <div className="rounded-xl border border-line bg-panelSoft p-3">
      <div className="flex items-start justify-between gap-2">
        <p className="text-[11px] text-slate-500">{quote.label}</p>
        <span className="rounded-md bg-ink px-1.5 py-0.5 text-[9px] text-slate-500">{quote.source}</span>
      </div>
      <p className={cx("mt-1 font-semibold", compact ? "text-xs" : "text-sm")}>{quote.value.toLocaleString("ko-KR")}</p>
      <p className={cx("mt-1 text-xs font-semibold", quote.changePercent >= 0 ? "text-gain" : "text-loss")}>
        {signedPct(quote.changePercent)}
      </p>
      <p className="mt-1 text-[10px] text-slate-500">{quote.session}</p>
    </div>
  );
}

function MarketInsightCard({ insight }: { insight: MarketInsight }) {
  return (
    <div className="rounded-xl border border-line bg-panelSoft p-3">
      <div className="flex items-center justify-between gap-2">
        <p className="text-sm font-semibold">{insight.title}</p>
        <span className={cx("rounded-md px-2 py-1 text-[10px]", insightToneClass(insight.tone))}>{insight.source}</span>
      </div>
      <p className="mt-2 text-xs leading-5 text-slate-400">{insight.summary}</p>
      <p className="mt-2 text-[11px] text-slate-600">업데이트 {insight.updatedAt}</p>
    </div>
  );
}

function OrderBook({ rows }: { rows: Array<{ side: "ask" | "bid"; price: number; volume: number }> }) {
  return (
    <div className="space-y-1 text-xs">
      {rows.map((row) => (
        <div key={`${row.side}-${row.price}`} className="grid grid-cols-[72px_1fr_64px] items-center gap-2">
          <span className={row.side === "ask" ? "text-gain" : "text-loss"}>{formatMoney(row.price)}</span>
          <div className="h-5 overflow-hidden rounded bg-ink">
            <div className={cx("h-full", row.side === "ask" ? "bg-gain/30" : "bg-loss/30")} style={{ width: `${Math.min(100, row.volume / 80)}%` }} />
          </div>
          <span className="text-right text-slate-300">{row.volume.toLocaleString("ko-KR")}</span>
        </div>
      ))}
    </div>
  );
}

function KiwoomStyleChart({ signal }: { signal: MarketSignal }) {
  const [timeframe, setTimeframe] = useState("1분");
  const data = signal.candles;
  const key = timeframe === "1분" ? "one" : timeframe === "3분" ? "three" : "five";

  return (
    <div>
      <div className="mb-3 flex gap-2">
        {["1분", "3분", "5분", "일", "6개월"].map((label) => (
          <button
            key={label}
            className={cx("rounded-lg border px-3 py-1.5 text-xs", timeframe === label ? "border-safe bg-safe/10 text-safe" : "border-line bg-ink text-slate-400")}
            onClick={() => setTimeframe(label)}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="rounded-xl border border-line bg-[#05090d] p-3">
        <div className="h-52">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <XAxis dataKey="time" tick={{ fill: "#64748b", fontSize: 10 }} axisLine={{ stroke: "#1f2937" }} tickLine={false} />
              <YAxis hide domain={["dataMin - 800", "dataMax + 800"]} />
              <Tooltip contentStyle={{ background: "#05090d", border: "1px solid #23333d", borderRadius: 8 }} />
              <Line type="monotone" dataKey={key} stroke="#ef4444" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="five" stroke="#f59e0b" strokeWidth={1.4} dot={false} />
              <Bar dataKey="three" fill="#3b82f655" />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-2 grid grid-cols-4 gap-2 text-[11px]">
          <span className="text-gain">시가 69,500</span>
          <span className="text-gain">고가 72,100</span>
          <span className="text-loss">저가 68,800</span>
          <span className="text-safe">거래량 182만</span>
        </div>
      </div>
    </div>
  );
}

function ExecutionTape({ executions }: { executions: Array<{ time: string; price: number; quantity: number; side: "매수" | "매도" }> }) {
  return (
    <div className="rounded-xl border border-line bg-ink p-2">
      <p className="mb-2 text-xs font-semibold text-slate-300">체결</p>
      <div className="space-y-1">
        {executions.map((item) => (
          <div key={`${item.time}-${item.quantity}`} className="rounded-lg bg-panelSoft px-2 py-1.5 text-[11px]">
            <p className={item.side === "매수" ? "text-gain" : "text-loss"}>{formatMoney(item.price)}</p>
            <p className="text-slate-500">{item.quantity}주 · {item.time.slice(3)}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function AiSupplyBlocks({ pair }: { pair: PairWatchlist }) {
  const blocks = [
    { label: "프로그램", value: pair.programSignal, tone: "safe" as const },
    { label: "기관", value: pair.institutionSignal, tone: "gain" as const },
    { label: "외국인", value: pair.foreignSignal, tone: "gain" as const },
    { label: "AI 수급", value: "매수 블럭 3회 감지 · 12초 후 소멸", tone: "caution" as const },
  ];

  return (
    <div className="mt-3 grid grid-cols-2 gap-2">
      {blocks.map((block) => (
        <div key={block.label} className="rounded-xl border border-line bg-ink p-3">
          <p className="text-[11px] text-slate-500">{block.label}</p>
          <p className={cx("mt-1 text-xs font-semibold", block.tone === "safe" && "text-safe", block.tone === "gain" && "text-gain", block.tone === "caution" && "text-caution")}>{block.value}</p>
        </div>
      ))}
    </div>
  );
}

function TradeTimelineList({ items }: { items: TradeTimeline[] }) {
  return (
    <div className="space-y-3">
      {items.map((item) => (
        <div key={item.id} className="rounded-2xl border border-line bg-panelSoft p-3">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-sm font-semibold">{item.symbolName}</p>
            <p className="text-xs text-slate-500">{item.date}</p>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {item.steps.map((step) => (
              <div key={step.label} className="rounded-xl bg-ink p-2">
                <p className="text-[11px] text-slate-500">{step.label}</p>
                <p className={cx("mt-1 text-[11px] font-semibold leading-4", step.tone === "gain" && "text-gain", step.tone === "loss" && "text-loss", step.tone === "safe" && "text-safe", step.tone === "caution" && "text-caution")}>{step.value}</p>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function ContributionBars({ items }: { items: Array<{ label: string; value: number }> }) {
  const max = Math.max(...items.map((item) => Math.abs(item.value)));
  return (
    <div className="space-y-3">
      {items.map((item) => (
        <div key={item.label} className="grid grid-cols-[96px_1fr] items-center gap-3">
          <span className="text-right text-xs text-slate-400">{item.label}</span>
          <div className="h-3 rounded-full bg-ink">
            <div className={cx("h-full rounded-full", item.value >= 0 ? "bg-gain" : "bg-loss")} style={{ width: `${Math.max(4, Math.abs(item.value) / max * 100)}%` }} />
          </div>
        </div>
      ))}
    </div>
  );
}

function KillSwitchModal({ confirmed, onClose, onPrimary }: { confirmed: boolean; onClose: () => void; onPrimary: () => void }) {
  return (
    <ModalFrame onClose={onClose}>
      <div className="space-y-4">
        <div className="flex items-start gap-3">
          <span className="rounded-full bg-gain/15 p-3 text-gain"><Power size={22} /></span>
          <div>
            <h2 className="text-lg font-bold">전체 자동매매 중지</h2>
            <p className="mt-1 text-sm leading-6 text-slate-400">
              {confirmed ? "2차 확인: “전체 중지” 버튼을 다시 눌러야 실제 데모 상태가 중지됩니다." : "1차 확인: 모든 자동매매를 즉시 중지하시겠습니까?"}
            </p>
          </div>
        </div>
        <button className="w-full rounded-xl bg-gain px-4 py-3 text-sm font-semibold text-white" onClick={onPrimary}>
          {confirmed ? "전체 중지" : "중지 확인"}
        </button>
      </div>
    </ModalFrame>
  );
}

function OrderReasonSheet({ order, onClose }: { order: Order; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end bg-black/60">
      <div className="w-full max-w-md rounded-t-2xl border border-line bg-panel p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-bold">주문 근거</h2>
          <button onClick={onClose}><X size={20} /></button>
        </div>
        <div className="space-y-2">
          <Row left="전략명" right={order.strategyName} />
          <Row left="신호 점수" right="74점" tone="safe" />
          <Row left="대장주 상승률" right="+3.2%" tone="gain" />
          <Row left="후속주 반응 지연" right="1.4%" tone="safe" />
          <Row left="거래대금 증가" right="2.1배" />
          <Row left="호가 불균형" right="매수 우위 1.36배" tone="safe" />
        </div>
      </div>
    </div>
  );
}

function ConfirmModal({ title, body, action, onClose, onConfirm }: { title: string; body: string; action: string; onClose: () => void; onConfirm: () => void }) {
  return (
    <ModalFrame onClose={onClose}>
      <h2 className="text-lg font-bold">{title}</h2>
      <p className="mt-2 text-sm leading-6 text-slate-400">{body}</p>
      <div className="mt-4 grid grid-cols-2 gap-2">
        <button className="rounded-xl border border-line px-4 py-3 text-sm" onClick={onClose}>취소</button>
        <button className="rounded-xl bg-gain px-4 py-3 text-sm font-semibold text-white" onClick={onConfirm}>{action}</button>
      </div>
    </ModalFrame>
  );
}

function ModalFrame({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/65 px-5">
      <div className="w-full max-w-sm rounded-2xl border border-line bg-panel p-5 shadow-glow">
        <div className="mb-2 flex justify-end">
          <button onClick={onClose}><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function SettingsToggle({ enabled }: { enabled: boolean }) {
  return <span className={cx("relative h-7 w-12 rounded-full", enabled ? "bg-safe" : "bg-slate-800")}><span className={cx("absolute top-1 h-5 w-5 rounded-full bg-ink transition", enabled ? "right-1" : "left-1")} /></span>;
}

function ToggleRow({ label, enabled, onClick }: { label: string; enabled: boolean; onClick: () => void }) {
  return (
    <button className="mb-2 flex w-full items-center justify-between rounded-xl border border-line bg-panelSoft px-3 py-3 text-sm" onClick={onClick}>
      {label}
      <SettingsToggle enabled={enabled} />
    </button>
  );
}

function MoneyInput({ label, value, suffix, onChange }: { label: string; value: number; suffix: string; onChange: (value: string) => void }) {
  return (
    <label className="mb-3 block">
      <span className="text-xs text-slate-400">{label}</span>
      <span className="mt-2 flex items-center rounded-xl border border-line bg-ink px-3">
        <input className="min-w-0 flex-1 bg-transparent py-3 text-right outline-none" value={formatMoney(value)} onChange={(event) => onChange(event.target.value)} />
        <span className="ml-2 text-xs text-slate-400">{suffix}</span>
      </span>
    </label>
  );
}

function BrokerSecretInput({
  label,
  value,
  placeholder,
  secret,
  onChange,
}: {
  label: string;
  value: string;
  placeholder: string;
  secret?: boolean;
  onChange: (value: string) => void;
}) {
  return (
    <label className="block">
      <span className="text-xs text-slate-400">{label}</span>
      <input
        className="mt-2 w-full rounded-xl border border-line bg-ink px-3 py-3 text-sm outline-none placeholder:text-slate-600"
        type={secret ? "password" : "text"}
        value={value}
        placeholder={placeholder}
        autoComplete="off"
        spellCheck={false}
        onChange={(event) => onChange(event.target.value)}
      />
    </label>
  );
}

function BottomNav({ active, onSelect }: { active: Tab; onSelect: (tab: Tab) => void }) {
  return (
    <nav className="fixed bottom-0 left-1/2 z-30 grid w-full max-w-md -translate-x-1/2 grid-cols-5 border-t border-line bg-panel/98 px-2 pb-[calc(0.5rem+env(safe-area-inset-bottom))] pt-2 backdrop-blur">
      {navItems.map((item) => {
        const Icon = item.icon;
        return (
          <button key={item.id} className={cx("flex flex-col items-center gap-1 rounded-xl py-2 text-xs", active === item.id ? "text-safe" : "text-slate-400")} onClick={() => onSelect(item.id)}>
            <Icon size={20} />
            {item.label}
          </button>
        );
      })}
    </nav>
  );
}

function Panel({ title, subtitle, action, children }: { title: string; subtitle?: string; action?: string; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-line bg-panel p-4">
      <div className="mb-3 flex items-start justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-slate-100">{title}</h2>
          {subtitle ? <p className="mt-1 text-xs text-slate-500">{subtitle}</p> : null}
        </div>
        {action ? <span className="shrink-0 text-xs font-semibold text-safe">{action}</span> : null}
      </div>
      {children}
    </section>
  );
}

function MiniMetric({ label, value, tone }: { label: string; value: string; tone?: "gain" | "loss" | "safe" | "caution" }) {
  return (
    <div className="rounded-xl border border-line bg-panelSoft p-3">
      <p className="text-[11px] text-slate-500">{label}</p>
      <p className={cx("mt-1 text-sm font-semibold", tone === "gain" && "text-gain", tone === "loss" && "text-loss", tone === "safe" && "text-safe", tone === "caution" && "text-caution")}>{value}</p>
    </div>
  );
}

function AssetMetric({ label, value, tone }: { label: string; value: string; tone?: string }) {
  return (
    <div className="border-r border-line p-3 last:border-r-0">
      <p className="text-[11px] text-slate-500">{label}</p>
      <p className={cx("mt-1 text-sm font-semibold", tone)}>{value}</p>
    </div>
  );
}

function Row({ left, right, tone }: { left: string; right: string; tone?: "gain" | "loss" | "safe" | "caution" }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-line py-2 text-sm last:border-b-0">
      <span className="min-w-0 text-slate-300">{left}</span>
      <span className={cx("shrink-0 text-right font-semibold", tone === "gain" && "text-gain", tone === "loss" && "text-loss", tone === "safe" && "text-safe", tone === "caution" && "text-caution")}>{right}</span>
    </div>
  );
}

function Segmented({ labels, active, onChange }: { labels: string[]; active: string; onChange: (label: string) => void }) {
  return (
    <div className="flex gap-2 overflow-x-auto rounded-2xl border border-line bg-panel p-1 no-scrollbar">
      {labels.map((label) => (
        <button key={label} className={cx("shrink-0 rounded-xl px-3 py-2 text-xs", active === label ? "bg-panelSoft text-safe" : "text-slate-400")} onClick={() => onChange(label)}>
          {label}
        </button>
      ))}
    </div>
  );
}

function Badge({ label, className }: { label: string; className?: string }) {
  return <span className={cx("rounded-full border px-2.5 py-1 text-[11px] font-semibold", className)}>{label}</span>;
}

function IconButton({ label, icon: Icon, onClick, primary }: { label: string; icon: React.ComponentType<{ size?: number }>; onClick: () => void; primary?: boolean }) {
  return (
    <button className={cx("flex items-center justify-center gap-2 rounded-xl px-3 py-3 text-sm font-semibold", primary ? "bg-safe text-ink" : "border border-line bg-panelSoft text-slate-100")} onClick={onClick}>
      <Icon size={16} /> {label}
    </button>
  );
}

function SmallButton({ label, icon: Icon, onClick, danger }: { label: string; icon: React.ComponentType<{ size?: number }>; onClick?: () => void; danger?: boolean }) {
  return (
    <button className={cx("flex min-h-11 flex-col items-center justify-center gap-1 rounded-xl border px-2 py-2 text-[11px]", danger ? "border-gain/35 bg-gain/10 text-gain" : "border-line bg-panelSoft text-slate-200")} onClick={onClick}>
      <Icon size={14} /> {label}
    </button>
  );
}

function BackTitle({ title, onBack }: { title: string; onBack: () => void }) {
  return (
    <div className="flex items-center gap-2">
      <button className="rounded-xl border border-line bg-panel p-2" onClick={onBack}><ChevronLeft size={18} /></button>
      <h1 className="text-xl font-bold">{title}</h1>
    </div>
  );
}

function formatMoney(value: number) {
  return Math.round(value).toLocaleString("ko-KR");
}

function formatSignedMoney(value: number) {
  const prefix = value > 0 ? "+" : "";
  return `${prefix}${formatMoney(value)}`;
}

function strategyLabel(key: string) {
  const labels: Record<string, string> = {
    pullback: "매매 전략 1번(눌림)",
    momentum: "매매 전략 2번(급등주)",
    scalping: "매매 전략 3번(스캘핑)",
    total: "최종 손익",
  };

  return labels[key] ?? key;
}

function insightToneClass(tone: MarketInsight["tone"]) {
  if (tone === "gain") return "bg-gain/15 text-gain";
  if (tone === "loss") return "bg-loss/15 text-loss";
  if (tone === "safe") return "bg-safe/15 text-safe";
  return "bg-caution/15 text-caution";
}

function pairFromSymbol(symbol: string) {
  return watchPairs.find((pair) => pair.leaderSymbol === symbol || pair.followerSymbol === symbol)?.id ?? watchPairs[0].id;
}

function statusTone(status: CandidateStatus): "gain" | "loss" | "safe" | "caution" {
  if (status === "진입 후보" || status === "보유 중") return "safe";
  if (status === "제외") return "loss";
  return "caution";
}
