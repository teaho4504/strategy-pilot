import { NextResponse } from "next/server";
import { getMarketSummary } from "../../../../services/marketService";

export async function GET() {
  return NextResponse.json(await getMarketSummary());
}
