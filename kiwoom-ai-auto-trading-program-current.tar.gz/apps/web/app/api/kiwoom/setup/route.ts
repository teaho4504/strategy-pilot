import { NextResponse } from "next/server";
import { prepareBrokerCredentialSetup } from "../../../../services/brokerCredentialService";

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  return NextResponse.json(await prepareBrokerCredentialSetup(body));
}
