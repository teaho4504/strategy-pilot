import { NextResponse } from "next/server";
import { getKiwoomConnectionStatus } from "../../../../services/kiwoomService";

export async function POST() {
  const status = getKiwoomConnectionStatus();

  if (!status.configured) {
    return NextResponse.json(
      {
        ...status,
        connected: false,
        message: `로그인 시작 불가 · 누락 환경변수: ${status.missingEnv.join(", ")}`,
      },
      { status: 200 },
    );
  }

  return NextResponse.json({
    ...status,
    connected: false,
    message: "키움 로그인 토큰 발급은 서버 자동매매 엔진에서 수행 예정입니다. 프론트는 토큰/시크릿을 보관하지 않습니다.",
  });
}
