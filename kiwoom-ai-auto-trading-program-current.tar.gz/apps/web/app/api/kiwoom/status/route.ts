import { NextResponse } from "next/server";
import { getKiwoomConnectionStatus } from "../../../../services/kiwoomService";

export async function GET() {
  return NextResponse.json(getKiwoomConnectionStatus());
}
