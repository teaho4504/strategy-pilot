import { NextResponse } from "next/server";
import { getKiwoomRealtimeBridge } from "../../../../services/kiwoomRealtimeBridge";

export const dynamic = "force-dynamic";

export async function GET() {
  const symbol = process.env.REALTIME_HEALTHCHECK_SYMBOL ?? "042700";
  const snapshot = await getKiwoomRealtimeBridge().snapshot(symbol);

  return NextResponse.json({
    provider: snapshot.provider,
    mode: snapshot.mode,
    connected: snapshot.connected,
    latencyMs: snapshot.latencyMs,
    updatedAt: snapshot.updatedAt,
    symbol,
    price: snapshot.signal.price,
    changePercent: snapshot.signal.changePercent,
    statusMessage: snapshot.statusMessage,
    requiredForKiwoom: [
      "REALTIME_PROVIDER=kiwoom",
      "KIWOOM_APP_KEY",
      "KIWOOM_APP_SECRET",
      "KIWOOM_API_BASE_URL",
      "KIWOOM_WEBSOCKET_URL",
      "AWS_FIXED_IP 키움 허용 IP 등록",
    ],
  });
}
