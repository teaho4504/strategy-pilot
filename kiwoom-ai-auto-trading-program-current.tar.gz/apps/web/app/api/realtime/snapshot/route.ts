import { NextResponse } from "next/server";
import { getKiwoomRealtimeBridge } from "../../../../services/kiwoomRealtimeBridge";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const symbol = url.searchParams.get("symbol") ?? "042700";
  return NextResponse.json(await getKiwoomRealtimeBridge().snapshot(symbol));
}
