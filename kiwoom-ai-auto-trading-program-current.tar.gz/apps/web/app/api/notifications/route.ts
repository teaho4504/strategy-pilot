import { NextResponse } from "next/server";

type NotificationChannel = "slack" | "kakao";

interface NotificationPayload {
  channel?: NotificationChannel;
  eventType?: string;
  title?: string;
  body?: string;
  order?: {
    symbolName?: string;
    side?: string;
    status?: string;
    quantity?: number;
    price?: number;
    submittedAt?: string;
    strategyName?: string;
  };
}

const channelEnv: Record<NotificationChannel, string> = {
  slack: "SLACK_WEBHOOK_URL",
  kakao: "KAKAO_WEBHOOK_URL",
};

export async function POST(request: Request) {
  let payload: NotificationPayload;

  try {
    payload = (await request.json()) as NotificationPayload;
  } catch {
    return NextResponse.json({ ok: false, message: "잘못된 알림 요청입니다." }, { status: 400 });
  }

  const channel = payload.channel;
  if (channel !== "slack" && channel !== "kakao") {
    return NextResponse.json({ ok: false, message: "지원하지 않는 알림 채널입니다." }, { status: 400 });
  }

  const webhookUrl = process.env[channelEnv[channel]];
  if (!webhookUrl) {
    return NextResponse.json(
      {
        ok: false,
        message: `${channelEnv[channel]} 환경변수가 설정되지 않았습니다.`,
      },
      { status: 200 },
    );
  }

  const text = buildNotificationText(payload);
  const response = await fetch(webhookUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(channel === "slack" ? { text } : { text, title: payload.title ?? "자동매매 알림" }),
  });

  if (!response.ok) {
    return NextResponse.json(
      { ok: false, message: `${channel} 전송 실패: ${response.status}` },
      { status: 502 },
    );
  }

  return NextResponse.json({ ok: true, message: `${channel} 알림 전송 완료` });
}

function buildNotificationText(payload: NotificationPayload) {
  const order = payload.order;
  const lines = [
    `[${payload.eventType ?? "trading_event"}] ${payload.title ?? "자동매매 알림"}`,
    payload.body,
    order?.strategyName ? `전략: ${order.strategyName}` : undefined,
    order?.symbolName ? `종목: ${order.symbolName} ${order.side ?? ""} ${order.status ?? ""}` : undefined,
  ];

  return lines.filter(Boolean).join("\n");
}
