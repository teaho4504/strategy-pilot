import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Kiwoom Auto Trading",
    short_name: "KiwoomBot",
    description: "Mobile auto-trading dashboard for Kiwoom REST API.",
    start_url: "/",
    scope: "/",
    display: "standalone",
    background_color: "#071014",
    theme_color: "#071014",
    orientation: "portrait",
    lang: "ko-KR",
    categories: ["finance", "productivity"],
    icons: [
      {
        src: "/icons/app-icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "any",
      },
      {
        src: "/icons/maskable-icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "maskable",
      },
    ],
  };
}
