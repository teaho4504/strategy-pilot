import { DashboardApp } from "../page";

export default function SettingsPage() {
  return <DashboardApp initialTab="settings" />;
}
