import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#071014",
        panel: "#101a20",
        panelSoft: "#15232b",
        line: "#23333d",
        gain: "#ef4444",
        loss: "#3b82f6",
        caution: "#f59e0b",
        safe: "#14b8a6",
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(255,255,255,0.05), 0 18px 40px rgba(0,0,0,0.32)",
      },
    },
  },
  plugins: [],
};

export default config;
