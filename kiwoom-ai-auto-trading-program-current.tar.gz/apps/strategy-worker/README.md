# Python Strategy Worker

Python worker는 주문 실행 서버가 아닙니다. 백테스트, 뉴스/테마 분석, 후보군 점수 계산처럼 Python 생태계가 유리한 작업만 담당합니다.

실제 주문 가능 여부와 리스크 검증은 Node/TypeScript trading engine에서만 처리합니다.

## Local Run

```bash
python3 apps/strategy-worker/src/server.py
```

Endpoints:

```text
GET /health
GET /analysis/candidates
GET /analysis/backtest
```
