from __future__ import annotations

import json
import math
import os
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any


STARTED_AT = time.time()
PORT = int(os.getenv("PYTHON_WORKER_PORT", "8790"))
MODE = os.getenv("APP_MODE", "demo")


def now_ms() -> int:
    return int(time.time() * 1000)


def build_candidates() -> dict[str, Any]:
    swing = math.sin(time.time() / 12)
    candidates = [
        {
            "symbol": "042700",
            "name": "한미반도체",
            "strategy": "눌림 후속주 스캘핑",
            "score": round(78 + swing * 4, 1),
            "status": "진입 후보",
            "reason": "대장주 SK하이닉스 급등 대비 후속주 반응 지연과 매수 호가 우위가 동시에 발생",
            "features": {
                "leaderChange1m": round(4.8 + swing * 0.2, 2),
                "relativeLag": round(2.6 + swing * 0.15, 2),
                "turnoverRatio5m": round(2.3 + swing * 0.1, 2),
                "bidAskImbalance": round(1.38 + swing * 0.03, 2),
                "programFlow": "순매수 증가",
            },
        },
        {
            "symbol": "034020",
            "name": "두산에너빌리티",
            "strategy": "급등주 추세 추적",
            "score": round(67 + swing * 3, 1),
            "status": "감시",
            "reason": "거래대금은 증가했지만 후속 체결강도와 수급 확인이 추가로 필요",
            "features": {
                "leaderChange1m": round(2.1 + swing * 0.1, 2),
                "relativeLag": round(0.7 + swing * 0.05, 2),
                "turnoverRatio5m": round(1.8 + swing * 0.1, 2),
                "bidAskImbalance": round(1.18 + swing * 0.02, 2),
                "programFlow": "중립",
            },
        },
    ]
    return {
        "service": "python-strategy-worker",
        "mode": MODE,
        "role": "analysis-only",
        "orderExecution": "disabled",
        "candidates": candidates,
        "updatedAtMs": now_ms(),
    }


def build_backtest_summary() -> dict[str, Any]:
    return {
        "service": "python-strategy-worker",
        "mode": MODE,
        "role": "analysis-only",
        "period": "mock-6m",
        "strategies": [
            {"name": "눌림", "winRate": 58.4, "averageHoldMinutes": 4.6, "mdd": -3.1, "pnlKrw": 842500},
            {"name": "급등주", "winRate": 51.2, "averageHoldMinutes": 7.8, "mdd": -5.4, "pnlKrw": 412000},
            {"name": "스캘핑", "winRate": 62.7, "averageHoldMinutes": 2.3, "mdd": -2.2, "pnlKrw": 623000},
        ],
        "note": "Python worker provides analysis signals only. Node trading engine remains the final order gate.",
        "updatedAtMs": now_ms(),
    }


def response(body: dict[str, Any]) -> bytes:
    return json.dumps(body, ensure_ascii=False, indent=2).encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        routes = {
            "/health": self.health,
            "/analysis/candidates": self.analysis_candidates,
            "/analysis/backtest": self.analysis_backtest,
        }
        handler = routes.get(self.path.split("?")[0])
        if handler is None:
            self.send_json(404, {"ok": False, "error": "Not found"})
            return
        handler()

    def health(self) -> None:
        self.send_json(
            200,
            {
                "ok": True,
                "service": "python-strategy-worker",
                "mode": MODE,
                "role": "analysis-only",
                "uptimeSeconds": round(time.time() - STARTED_AT),
            },
        )

    def analysis_candidates(self) -> None:
        self.send_json(200, build_candidates())

    def analysis_backtest(self) -> None:
        self.send_json(200, build_backtest_summary())

    def send_json(self, status: int, body: dict[str, Any]) -> None:
        payload = response(body)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", os.getenv("ALLOWED_ORIGIN", "*"))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format: str, *args: Any) -> None:
        return


if __name__ == "__main__":
    server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print(f"Python strategy worker listening on http://127.0.0.1:{PORT}")
    server.serve_forever()
