export const createSchemaSql = `
create table if not exists pair_watchlists (
  id uuid primary key default gen_random_uuid(),
  leader_symbol text not null,
  leader_name text not null,
  follower_symbol text not null,
  follower_name text not null,
  relationship_type text not null,
  description text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists strategies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  status text not null,
  strategy_type text not null,
  pair_watchlist_id uuid references pair_watchlists(id),
  entry_conditions_json jsonb not null,
  exit_conditions_json jsonb not null default '{}'::jsonb,
  risk_config_json jsonb not null,
  daily_order_limit integer not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists signals (
  id uuid primary key default gen_random_uuid(),
  strategy_id uuid references strategies(id),
  leader_symbol text,
  follower_symbol text,
  signal_type text not null,
  score numeric not null,
  snapshot_json jsonb not null,
  status text not null,
  created_at timestamptz not null default now()
);

create table if not exists order_intents (
  id uuid primary key default gen_random_uuid(),
  strategy_id uuid references strategies(id),
  signal_id uuid references signals(id),
  symbol text not null,
  side text not null,
  quantity integer not null,
  price_type text not null,
  requested_price numeric,
  risk_check_result jsonb not null,
  status text not null,
  duplicate_key text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  order_intent_id uuid references order_intents(id),
  broker_order_id text,
  symbol text not null,
  side text not null,
  quantity integer not null,
  price numeric,
  status text not null,
  submitted_at timestamptz,
  updated_at timestamptz not null default now()
);

create table if not exists fills (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references orders(id),
  symbol text not null,
  filled_quantity integer not null,
  filled_price numeric not null,
  filled_at timestamptz not null
);

create table if not exists account_snapshots (
  id uuid primary key default gen_random_uuid(),
  total_asset numeric not null,
  cash numeric not null,
  available_cash numeric not null,
  daily_realized_pnl numeric not null,
  daily_unrealized_pnl numeric not null,
  positions_json jsonb not null,
  captured_at timestamptz not null default now()
);
`;
