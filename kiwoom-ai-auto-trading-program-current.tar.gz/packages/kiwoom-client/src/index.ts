import type { MarketTick, OrderSide } from "@kiwoom/core";

export interface KiwoomClientConfig {
  appKey: string;
  secretKey: string;
  baseUrl?: string;
  websocketUrl?: string;
  mock?: boolean;
}

export interface TokenResponse {
  expires_dt: string;
  token_type: string;
  token: string;
  return_code: number;
  return_msg: string;
}

export interface KiwoomOrderRequest {
  symbol: string;
  side: OrderSide;
  quantity: number;
  priceType: "market" | "limit";
  price?: number;
}

export class KiwoomRestClient {
  private readonly baseUrl: string;
  private token: string | null = null;

  constructor(private readonly config: KiwoomClientConfig) {
    this.baseUrl = config.baseUrl ?? (config.mock ? "https://mockapi.kiwoom.com" : "https://api.kiwoom.com");
  }

  async issueToken() {
    const response = await this.post<TokenResponse>("/oauth2/token", {
      grant_type: "client_credentials",
      appkey: this.config.appKey,
      secretkey: this.config.secretKey,
    });
    this.token = response.token;
    return response;
  }

  async submitStockOrder(order: KiwoomOrderRequest) {
    this.ensureToken();
    const trId = order.side === "매수" ? "kt10000" : "kt10001";

    return this.post("/api/dostk/ordr", {
      tr_id: trId,
      stk_cd: order.symbol,
      ord_qty: String(order.quantity),
      ord_uv: order.priceType === "market" ? "0" : String(order.price ?? 0),
      trde_tp: order.priceType === "market" ? "3" : "0",
    });
  }

  async getAccountSnapshot() {
    this.ensureToken();
    return this.post("/api/dostk/acnt", {
      tr_id: "kt00018",
    });
  }

  private async post<T = unknown>(path: string, body: Record<string, unknown>): Promise<T> {
    const response = await fetch(`${this.baseUrl}${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json;charset=UTF-8",
        ...(this.token ? { Authorization: `Bearer ${this.token}` } : {}),
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      throw new Error(`Kiwoom REST request failed: ${response.status} ${response.statusText}`);
    }

    return response.json() as Promise<T>;
  }

  private ensureToken() {
    if (!this.token) {
      throw new Error("Kiwoom OAuth token is not issued. Call issueToken() before API requests.");
    }
  }
}

export interface RealtimeSubscription {
  groupNo: string;
  items: string[];
  types: Array<"00" | "04" | "0B" | "0C" | "0D" | "0H">;
}

export class KiwoomRealtimeClient {
  private socket: WebSocket | null = null;
  private readonly websocketUrl: string;
  private loggedIn = false;
  private pendingSubscriptions: RealtimeSubscription[] = [];

  constructor(private readonly config: KiwoomClientConfig) {
    this.websocketUrl =
      config.websocketUrl ??
      (config.mock ? "wss://mockapi.kiwoom.com:10000/api/dostk/websocket" : "wss://api.kiwoom.com:10000/api/dostk/websocket");
  }

  connect(token: string, onTick: (tick: Partial<MarketTick>) => void, onStatus?: (status: string) => void) {
    if (typeof WebSocket === "undefined") {
      throw new Error("Global WebSocket is unavailable. In Node.js, inject ws or run on Node 22+.");
    }

    this.socket = new WebSocket(this.websocketUrl);
    this.socket.onopen = () => {
      onStatus?.("connected");
      this.socket?.send(JSON.stringify({ trnm: "LOGIN", token }));
    };
    this.socket.onclose = () => onStatus?.("closed");
    this.socket.onerror = () => onStatus?.("error");
    this.socket.onmessage = (event) => {
      const data = JSON.parse(String(event.data)) as Record<string, unknown>;
      const trnm = String(data.trnm ?? "");

      if (trnm === "PING") {
        this.socket?.send(JSON.stringify(data));
        onStatus?.("ping");
        return;
      }

      if (trnm === "LOGIN") {
        const returnCode = Number(data.return_code ?? data.returnCode ?? -1);
        this.loggedIn = returnCode === 0;
        onStatus?.(this.loggedIn ? "login" : `login_failed:${String(data.return_msg ?? "")}`);
        if (this.loggedIn) this.flushSubscriptions();
        return;
      }

      onTick(normalizeRealtimeMessage(data));
    };
  }

  subscribe(subscription: RealtimeSubscription) {
    if (!this.loggedIn || !this.socket || this.socket.readyState !== WebSocket.OPEN) {
      this.pendingSubscriptions.push(subscription);
      return;
    }

    this.sendSubscription(subscription);
  }

  close() {
    this.socket?.close();
    this.socket = null;
    this.loggedIn = false;
    this.pendingSubscriptions = [];
  }

  private flushSubscriptions() {
    const subscriptions = [...this.pendingSubscriptions];
    this.pendingSubscriptions = [];
    subscriptions.forEach((subscription) => this.sendSubscription(subscription));
  }

  private sendSubscription(subscription: RealtimeSubscription) {
    this.socket?.send(
      JSON.stringify({
        trnm: "REG",
        grp_no: subscription.groupNo,
        refresh: "1",
        data: [
          {
            item: subscription.items,
            type: subscription.types,
          },
        ],
      }),
    );
  }
}

function normalizeRealtimeMessage(message: Record<string, unknown>): Partial<MarketTick> {
  const values = Array.isArray(message.data) ? (message.data[0] as Record<string, unknown> | undefined) : undefined;
  const source = values ?? message;

  return {
    symbol: String(source.item ?? source.stk_cd ?? source.stk_cd_iem ?? message.item ?? ""),
    price: normalizeNumber(source.price ?? source.cur_prc ?? source.stck_prpr ?? source["10"] ?? 0),
    changePercent: normalizeNumber(source.change_percent ?? source.flu_rt ?? source.prdy_ctrt ?? source["12"] ?? 0),
    updatedAt: new Date().toISOString(),
  };
}

function normalizeNumber(value: unknown) {
  if (typeof value === "number") return value;
  return Number(String(value ?? "0").replace(/,/g, "").replace(/^\+/, "")) || 0;
}
