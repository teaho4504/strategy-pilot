export type TradingMode = "mock" | "live";
export type StrategyStatus = "실행 중" | "대기" | "일시정지" | "오류";
export type OrderSide = "매수" | "매도";

export interface PairWatchlist {
  id: string;
  leaderSymbol: string;
  leaderName: string;
  followerSymbol: string;
  followerName: string;
  relationshipType: "theme" | "supply_chain" | "sector" | "custom";
  description: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface EntryCondition {
  field:
    | "leader_price_change_1m"
    | "leader_turnover_ratio_5m"
    | "follower_relative_lag"
    | "follower_turnover_ratio_5m"
    | "bid_ask_imbalance"
    | "program_net_buy_score";
  operator: ">=" | ">" | "<=" | "<" | "=";
  value: number;
  score: number;
}

export interface RiskConfig {
  dailyMaxLossKrw: number;
  dailyMaxLossPercent: number;
  strategyMaxCapital: number;
  symbolMaxWeightPercent: number;
  maxOpenPositions: number;
  maxOrderAmount: number;
  stopLossPercent: number;
  takeProfitPercent: number;
  maxHoldingMinutes: number;
  maxEntriesPerDay: number;
}

export interface Strategy {
  id: string;
  name: string;
  description: string;
  status: StrategyStatus;
  strategyType: "pair_lag_scalping" | "turnover_breakout_scalping";
  pairWatchlistId: string;
  entryConditions: EntryCondition[];
  risk: RiskConfig;
  dailyOrderLimit: number;
  todayOrderCount: number;
  todayPnlPercent: number;
  lastSignalAt: string;
  createdAt: string;
  updatedAt: string;
}

export interface MarketTick {
  symbol: string;
  name: string;
  price: number;
  changePercent: number;
  turnoverRatio5m: number;
  turnoverKrw: number;
  tradeStrength: number;
  bidVolume: number;
  askVolume: number;
  programNetBuyScore: number;
  foreignNetBuyScore: number;
  institutionNetBuyScore: number;
  updatedAt: string;
}

export interface SignalEvaluation {
  passed: boolean;
  score: number;
  requiredScore: number;
  reasons: Array<{ label: string; passed: boolean; score: number; value: number; threshold: number }>;
}

export interface OrderIntentKeyInput {
  strategyId: string;
  signalId: string;
  symbol: string;
  side: OrderSide | string;
  tradingDate: string;
}

export function formatKrw(value: number) {
  return `${Math.round(value).toLocaleString("ko-KR")}원`;
}

export function buildOrderIntentKey(input: OrderIntentKeyInput) {
  return [input.strategyId, input.symbol, input.side, input.signalId, input.tradingDate].join(":");
}

export function evaluatePairLagScalping(
  pair: PairWatchlist,
  ticks: Record<string, MarketTick>,
  strategy: Strategy,
  requiredScore = 70,
): SignalEvaluation {
  const leader = ticks[pair.leaderSymbol];
  const follower = ticks[pair.followerSymbol];

  if (!leader || !follower) {
    return { passed: false, score: 0, requiredScore, reasons: [] };
  }

  const values: Record<EntryCondition["field"], number> = {
    leader_price_change_1m: leader.changePercent,
    leader_turnover_ratio_5m: leader.turnoverRatio5m,
    follower_relative_lag: Math.max(0, leader.changePercent - follower.changePercent),
    follower_turnover_ratio_5m: follower.turnoverRatio5m,
    bid_ask_imbalance: follower.askVolume === 0 ? 0 : follower.bidVolume / follower.askVolume,
    program_net_buy_score: follower.programNetBuyScore,
  };

  const reasons = strategy.entryConditions.map((condition) => {
    const value = values[condition.field];
    const passed = compare(value, condition.operator, condition.value);
    return {
      label: condition.field,
      passed,
      score: passed ? condition.score : 0,
      value,
      threshold: condition.value,
    };
  });

  const score = reasons.reduce((sum, item) => sum + item.score, 0);
  return {
    passed: score >= requiredScore,
    score,
    requiredScore,
    reasons,
  };
}

export function compare(actual: number, operator: EntryCondition["operator"], expected: number) {
  switch (operator) {
    case ">=":
      return actual >= expected;
    case ">":
      return actual > expected;
    case "<=":
      return actual <= expected;
    case "<":
      return actual < expected;
    case "=":
      return actual === expected;
  }
}

export function validateRiskBeforeOrder(params: {
  risk: RiskConfig;
  dailyLossKrw: number;
  dailyLossPercent: number;
  openPositions: number;
  orderAmount: number;
  entriesToday: number;
  apiConnected: boolean;
  killSwitchActive: boolean;
}) {
  const failures: string[] = [];

  if (params.killSwitchActive) failures.push("Kill Switch active");
  if (!params.apiConnected) failures.push("Kiwoom API disconnected");
  if (params.dailyLossKrw >= params.risk.dailyMaxLossKrw) failures.push("Daily loss amount exceeded");
  if (params.dailyLossPercent >= params.risk.dailyMaxLossPercent) failures.push("Daily loss percent exceeded");
  if (params.openPositions >= params.risk.maxOpenPositions) failures.push("Open position limit exceeded");
  if (params.orderAmount > params.risk.maxOrderAmount) failures.push("Order amount exceeds limit");
  if (params.entriesToday >= params.risk.maxEntriesPerDay) failures.push("Strategy entry limit exceeded");

  return {
    passed: failures.length === 0,
    failures,
  };
}
