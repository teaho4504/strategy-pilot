# Deployment Runbook

이 문서는 현재 MVP를 GitHub, Vercel 또는 AWS Amplify, AWS Lightsail 또는 EC2로 배포하는 절차다.

## 1. GitHub 연결

현재 로컬 저장소의 원격 저장소:

```text
origin https://github.com/teaho4504/kiwoom-ai-auto-trading-program.git
```

배포 설정 파일까지 커밋한 뒤 `main` 브랜치로 push하면 Vercel, Amplify, GitHub Actions에서 배포 트리거로 사용할 수 있다.

## 2. 웹앱 배포

### Vercel

1. Vercel에서 GitHub 저장소를 Import한다.
2. Framework Preset은 Next.js로 둔다.
3. Root Directory는 저장소 루트로 둔다.
4. `vercel.json`이 아래 명령을 사용한다.

```text
Install: pnpm install --frozen-lockfile
Build: pnpm --filter @kiwoom/web build
Output: apps/web/.next
```

필수 환경변수:

```text
NEXT_PUBLIC_APP_URL=https://your-vercel-domain.vercel.app
NEXT_PUBLIC_API_BASE_URL=https://your-engine-api-domain
NEXT_PUBLIC_APP_MODE=demo
```

Vercel에서 키움 WebSocket을 직접 장시간 유지하는 구조는 권장하지 않는다. 실시간 시세는 EC2/Lightsail/ECS의 trading engine이 구독하고, Vercel 웹앱은 내부 API 스냅샷만 조회하는 구조로 운영한다.

### AWS Amplify

1. Amplify Hosting에서 GitHub 저장소를 연결한다.
2. Monorepo 앱 루트는 `apps/web`로 지정한다.
3. 빌드 설정은 저장소의 `amplify.yml`을 사용한다.
4. Vercel과 같은 `NEXT_PUBLIC_*` 환경변수를 등록한다.

## 3. 자동매매 엔진 배포

처음 MVP는 Lightsail 또는 EC2 한 대에서 Docker로 실행하는 방식이 가장 단순하다.

하이브리드 구조에서는 Node trading engine이 최종 주문 게이트이고, Python worker는 분석 전용이다.

```bash
docker compose -f docker-compose.cloud.yml up -d --build
```

개별 실행이 필요하면 아래처럼 엔진만 실행할 수 있다.

서버에서 실행:

```bash
git clone https://github.com/teaho4504/kiwoom-ai-auto-trading-program.git
cd kiwoom-ai-auto-trading-program
docker build -f Dockerfile.engine -t kiwoom-trading-engine .
docker run -d \
  --name kiwoom-trading-engine \
  --restart unless-stopped \
  -p 8788:8788 \
  -e APP_MODE=demo \
  -e PORT=8788 \
  -e PYTHON_WORKER_URL=http://strategy-worker:8790 \
  -e ALLOWED_ORIGIN=https://your-web-domain \
  -e KIWOOM_APP_KEY=replace-me \
  -e KIWOOM_APP_SECRET=replace-me \
  -e KIWOOM_ACCOUNT_NO=replace-me \
  -e DATABASE_URL=replace-me \
  -e REDIS_URL=replace-me \
  kiwoom-trading-engine
```

상태 확인:

```bash
curl http://SERVER_PUBLIC_IP:8788/health
curl http://SERVER_PUBLIC_IP:8788/runtime
curl http://SERVER_PUBLIC_IP:8788/market/snapshot
curl http://SERVER_PUBLIC_IP:8788/analysis/snapshot
```

실시간 시세를 키움 WebSocket으로 전환할 때 필요한 서버 환경변수:

```text
REALTIME_PROVIDER=kiwoom
REALTIME_HEALTHCHECK_SYMBOL=042700
KIWOOM_APP_KEY=...
KIWOOM_APP_SECRET=...
KIWOOM_API_BASE_URL=https://api.kiwoom.com
KIWOOM_WEBSOCKET_URL=wss://api.kiwoom.com:10000/api/dostk/websocket
AWS_FIXED_IP=...
KIWOOM_TEST_SYMBOL=039490
KIWOOM_REALTIME_TYPES=0B
```

실시간 수신 샘플 확인:

```bash
export REALTIME_PROVIDER=kiwoom
export KIWOOM_APP_KEY="..."
export KIWOOM_APP_SECRET="..."
export KIWOOM_API_BASE_URL="https://api.kiwoom.com"
export KIWOOM_WEBSOCKET_URL="wss://api.kiwoom.com:10000/api/dostk/websocket"
export KIWOOM_TEST_SYMBOL="039490"
export KIWOOM_REALTIME_TYPES="0B"
pnpm kiwoom:smoke
```

이 명령은 OAuth 토큰 발급, WebSocket LOGIN, `PING` echo, `REG` 등록, 첫 수신 tick 확인까지만 수행한다. 키와 토큰은 콘솔에 전체 출력하지 않고 마스킹한다.

증권사 연동 설정 저장 방식:

```text
SECRET_STORE_PROVIDER=dry-run            # 로컬/데모: 저장하지 않고 검증만 수행
SECRET_STORE_PROVIDER=env                # 서버 환경변수 수동 등록 방식
SECRET_STORE_PROVIDER=aws-secrets-manager
KIWOOM_SECRET_ID=kiwoom/auto-trading/prod
AWS_REGION=ap-northeast-2
```

운영 권장값은 `aws-secrets-manager`다. 현재 MVP 코드는 민감값을 브라우저에 저장하지 않고, 저장소 준비 상태와 누락 항목만 반환한다. 실제 Secrets Manager 쓰기 권한은 AWS IAM 역할이 붙은 엔진 서버에서만 활성화한다.

## 4. AWS 보안 설정

- EC2/Lightsail 방화벽은 `80`, `443`만 공개하는 구성이 좋다.
- MVP 테스트 중 `8788`을 직접 열 수 있지만, 실제 운영 전에는 Nginx 또는 ALB 뒤에 둔다.
- `KIWOOM_APP_SECRET`은 GitHub, 프론트엔드, 모바일 브라우저에 저장하지 않는다.
- 키움에서 고정 IP 등록이 필요하면 EC2 Elastic IP 또는 NAT Gateway Elastic IP를 사용한다.

## 5. 맥 전원과 운영 상태

아래 배포가 끝나면 맥을 꺼도 된다.

- 웹앱: Vercel 또는 Amplify에서 실행
- 엔진: AWS Lightsail 또는 EC2에서 Docker로 실행
- 시크릿: 서버 환경변수 또는 AWS Secrets Manager에 저장
- 도메인: 웹앱과 엔진 API가 HTTPS로 연결

로컬 `pnpm dev`와 `pnpm engine:server`에만 의존하는 상태에서는 맥을 꺼면 서비스가 중단된다.
