# Cloud Deployment Plan

이 프로젝트는 로컬 맥에서만 실행하는 앱이 아니라, 모바일에서 언제든 접속 가능한 클라우드형 구조로 운영하는 것을 목표로 한다.

## 결론

- GitHub만으로는 자동매매 서버가 계속 실행되지 않는다. GitHub는 코드 저장소와 배포 자동화 용도다.
- AWS, Vercel, Amplify, Render 같은 호스팅에 배포하면 맥을 꺼도 앱은 계속 접속 가능하다.
- 자동매매 엔진, 키움 API 토큰, 주문 실행, WebSocket 실시간 시세는 프론트가 아니라 서버에서만 처리한다.
- 모바일은 설치형 PWA 또는 앱 래퍼로 접속하고, 서버는 AWS에서 24시간 실행한다.

## 권장 구조

```text
Mobile PWA
  -> HTTPS
Frontend Hosting
  -> API calls
Backend API / Trading Engine
  -> Kiwoom REST API
  -> Kiwoom WebSocket realtime feed
Python Strategy Worker
  -> backtest, AI score, news/theme analysis
Database / Redis
  -> trade journal, signals, orders, fills, positions
Notification Worker
  -> Slack / Kakao alerts
```

## 각 서비스 역할

| 영역 | 권장 선택 | 역할 |
| --- | --- | --- |
| 코드 저장소 | GitHub | 소스 관리, 이슈, 배포 트리거 |
| 프론트엔드 | AWS Amplify, Vercel, CloudFront + S3 | 모바일 PWA 대시보드 제공 |
| 자동매매 엔진 | AWS ECS Fargate, EC2, Lightsail | 키움 API, WebSocket, 전략 판단, 주문 생성 |
| Python 분석 워커 | 같은 EC2/Lightsail 또는 ECS Worker | 백테스트, AI 점수, 뉴스/테마 분석 |
| DB | AWS RDS PostgreSQL | 매매일지, 주문, 체결, 포지션 저장 |
| 캐시/실시간 상태 | Redis 또는 ElastiCache | 실시간 호가, 체결, 감시 상태 |
| 시크릿 | AWS Secrets Manager 또는 SSM Parameter Store | Kiwoom App Key, Secret, webhook 보관 |
| 알림 | Slack webhook, Kakao business/webhook | 주문, 체결, 오류, 리스크 알림 |

## MVP 배포 순서

1. GitHub 저장소에 현재 모노레포를 올린다.
2. `apps/web`을 Vercel 또는 AWS Amplify에 배포한다.
3. `apps/trading-engine`을 EC2 또는 ECS Fargate에 배포한다.
4. `KIWOOM_APP_KEY`, `KIWOOM_APP_SECRET`, `KIWOOM_ACCOUNT_NO`는 서버 환경변수 또는 Secrets Manager에만 저장한다.
5. 프론트의 `NEXT_PUBLIC_API_BASE_URL`을 클라우드 API 주소로 변경한다.
6. 모바일에서 PWA로 설치 후 외부망에서 접속 테스트한다.
7. 모의투자 주문, 체결, 알림 로그를 DB에 저장한다.
8. 최소 2주 이상 모의투자 검증 후 실계좌 모드를 별도 승인 플래그로 분리한다.

## 맥을 꺼도 되는 조건

아래 조건이 충족되면 맥을 꺼도 된다.

- 프론트엔드가 Vercel, Amplify, S3/CloudFront 등에 배포되어 있다.
- 자동매매 엔진이 AWS EC2, ECS, Lightsail 등에서 실행 중이다.
- 키움 API 인증 정보가 AWS Secrets Manager 또는 서버 환경변수에 저장되어 있다.
- 실시간 시세 WebSocket과 주문 워커가 클라우드 서버에서 실행된다.
- 도메인과 HTTPS 인증서가 설정되어 있다.

반대로, `pnpm dev`로 로컬에서만 실행 중이면 맥을 꺼는 순간 앱과 엔진이 모두 중단된다.

## 키움 API 주의사항

- App Key, Secret, 계좌번호, OAuth token은 브라우저 저장소에 두면 안 된다.
- 실제 주문 요청은 서버 엔진에서만 실행한다.
- 키움 API가 접속 IP 제한 또는 고정 IP 등록을 요구하면 AWS NAT Gateway + Elastic IP 또는 EC2 Elastic IP를 사용한다.
- 실시간 시세, 호가, 체결 WebSocket은 모바일 브라우저가 직접 연결하지 않고 서버가 구독한 뒤 앱에 중계한다.
- 자동 주문은 기본값을 `demo` 또는 `paper`로 두고, `live` 전환은 서버 환경변수와 관리자 승인 UI가 모두 맞아야 가능하게 둔다.

## 현재 코드의 클라우드 준비 상태

- `apps/web`: 모바일 PWA 대시보드와 API 클라이언트 구조
- `apps/trading-engine`: 전략 평가 및 클라우드 상태 서버
- `apps/strategy-worker`: Python 기반 분석 전용 워커
- `packages/core`: 전략 평가, 리스크 검증 공통 로직
- `packages/kiwoom-client`: 키움 REST/WebSocket 클라이언트 인터페이스
- `packages/database`: DB 패키지 자리

## 엔진 서버 확인

로컬에서는 아래 명령으로 클라우드 엔진 서버 형태를 확인할 수 있다.

```bash
pnpm engine:server
```

확인 엔드포인트:

```text
GET http://127.0.0.1:8788/health
GET http://127.0.0.1:8788/runtime
GET http://127.0.0.1:8788/market/snapshot
GET http://127.0.0.1:8788/analysis/snapshot
```

`/runtime`은 환경변수 존재 여부만 반환하고 실제 시크릿 값은 반환하지 않는다.

Python 워커는 주문 실행 권한을 갖지 않는다. 분석 결과는 Node trading engine이 최종 리스크 검증과 주문 가능 여부 판단에 참고하는 보조 신호로만 사용한다.
