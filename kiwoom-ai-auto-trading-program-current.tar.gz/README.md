# Kiwoom AI Auto Trading Program

개인용 국내주식 자동매매 운영 웹앱입니다.

현재 구현 범위는 요청서의 **Phase 1: 화면 및 Mock 데이터**와 이후 연동을 위한 모노레포 골격입니다.

## 방향

- 웹 대시보드: `apps/web`
- 자동매매 엔진: `apps/trading-engine`
- Python 분석 워커: `apps/strategy-worker`
- 전략/리스크 공통 로직: `packages/core`
- 키움 REST/WebSocket 클라이언트: `packages/kiwoom-client`
- DB 스키마/저장소: `packages/database`

## API 선택

키움 공식 문서 기준으로 신규 웹앱은 **REST API + WebSocket 실시간시세** 구조를 기본으로 합니다.

- 실시간 시세: `wss://api.kiwoom.com:10000/api/dostk/websocket`
- 주문/계좌/초기 조회: `https://api.kiwoom.com`
- API Key, Secret, OAuth token은 프론트엔드에 저장하지 않습니다.
- 자동 주문은 `apps/trading-engine` 같은 상시 실행 프로세스에서만 수행합니다.

## 실행

```bash
npm install
npm run dev
```

웹앱은 기본적으로 `http://localhost:3000`에서 실행됩니다.

자동매매 엔진을 클라우드 서버 형태로 확인하려면 아래 명령을 사용합니다.

```bash
pnpm engine:server
```

Python 분석 워커는 아래 명령으로 실행합니다. 이 워커는 백테스트와 AI 점수 계산만 담당하고 주문 실행 권한은 갖지 않습니다.

```bash
pnpm worker:python
```

엔진 상태 확인:

```text
GET http://127.0.0.1:8788/health
GET http://127.0.0.1:8788/runtime
GET http://127.0.0.1:8788/market/snapshot
GET http://127.0.0.1:8788/analysis/snapshot
```

웹앱 실시간 시세 상태 확인:

```text
GET http://localhost:3000/api/realtime/status
GET http://localhost:3000/api/realtime/snapshot?symbol=042700
```

## 클라우드 운영

GitHub는 코드 저장소와 배포 트리거 역할이고, 실제 24시간 실행은 AWS 같은 호스팅 환경이 담당합니다.
프론트엔드는 Vercel, AWS Amplify, S3/CloudFront 같은 정적/Next.js 호스팅에 배포하고, 자동매매 엔진은 AWS EC2, Lightsail, ECS Fargate 같은 상시 실행 서버에 배포합니다.

이 구조로 배포되면 로컬 맥을 꺼도 모바일에서 접속할 수 있습니다. 단, 로컬의 `pnpm dev`만 실행 중인 상태라면 맥을 끄는 즉시 웹앱과 자동매매 엔진이 중단됩니다.

자세한 배포 구조는 [`docs/cloud-deployment.md`](docs/cloud-deployment.md)를 참고하세요.

실제 배포 절차는 [`docs/deployment-runbook.md`](docs/deployment-runbook.md)를 참고하세요.

## 개발 단계

1. Phase 1: 모바일 대시보드와 Mock 데이터
2. Phase 2: 키움 REST API 인증, 계좌, 주문 연결
3. Phase 3: WebSocket 실시간 시세, 호가, 체결 연결
4. Phase 4: 전략 및 리스크 엔진
5. Phase 5: 모의투자 운영
6. Phase 6: 소액 실계좌 운영
